# ProcessWindow - 智能版（集成智能匹配）
import customtkinter as ctk
from tkinter import ttk, VERTICAL, HORIZONTAL
import threading
import time

from app.ui.styles import ThemeColors, UIStyles
from app.ui.components import AnimatedButton
from app.core.smart_form_analyzer import SmartFormAnalyzer
from app.core.smart_form_filler import SmartFormFiller
from app.core.smart_matcher import SmartMatcher
from app.ui.mapping_canvas import MappingCanvas

class ProcessWindow(ctk.CTkToplevel):
    def __init__(self, master, excel_data, browser_tab_id, browser_mgr):
        super().__init__(master)
        
        self.title("Weaver (维沃) v1.0 Beta - 智能填表工作台")
        self.configure(fg_color=ThemeColors.BG_DARK)
        self.attributes("-topmost", True)
        
        self.excel_data = excel_data
        self.browser_tab_id = browser_tab_id
        self.browser_mgr = browser_mgr
        self.stop_event = threading.Event()
        
        # 智能系统
        self.web_fingerprints = []  # 所有网页元素
        self.matched_fingerprints = []  # 智能匹配后的元素（只显示这些）
        self.field_mapping = {}
        self.auto_mappings = {}  # 自动建议的映射
        
        self._set_perfect_split()
        self._scan_and_match()  # 扫描并智能匹配
        self._setup_layout()
        
        threading.Thread(target=self._lock_browser_layout, daemon=True).start()
        self.protocol("WM_DELETE_WINDOW", self.on_closing)

    def _get_target_tab(self):
        """获取目标标签页对象"""
        try:
            if self.browser_tab_id:
                return self.browser_mgr.page.get_tab(self.browser_tab_id)
        except: pass
        return self.browser_mgr.page

    def _scan_and_match(self):
        """扫描网页并执行智能匹配"""
        # 1. 扫描网页
        self._scan_web_form()
        
        # 2. 智能匹配
        if self.web_fingerprints and len(self.excel_data.columns) > 0:
            self.master.add_log("🎯 执行智能匹配...")
            
            match_result = SmartMatcher.match_fields(
                self.excel_data.columns.tolist(),
                self.web_fingerprints
            )
            
            # --- 去重逻辑（按基础标题去重，不包含行号后缀） ---
            # 原则：用户只需看到每种输入框标题，不需要看到每一行的每个输入框
            
            def get_base_name(fp):
                """获取基础名称（去掉行号后缀，用于去重）"""
                # 优先使用语义标签
                if fp.anchors.get('label'):
                    return fp.anchors['label'].strip()
                if fp.anchors.get('visual_label'):
                    return fp.anchors['visual_label'].strip()
                if fp.table_info.get('table_header'):
                    return fp.table_info['table_header'].strip()
                if fp.anchors.get('placeholder'):
                    return fp.anchors['placeholder'].strip()
                # 回退到 name/id
                return fp.features.get('name', '') or fp.raw_data.get('id', '')
            
            unique_fingerprints = []
            seen_base_names = set()
            
            # 先处理匹配项（优先保留）
            for excel_col, fp, score in match_result['matched']:
                base_name = get_base_name(fp)
                if base_name and base_name not in seen_base_names:
                    unique_fingerprints.append(fp)
                    seen_base_names.add(base_name)
            
            # 再处理未匹配项（按稳定性排序）
            unmatched_sorted = sorted(
                match_result['unmatched_web'],
                key=lambda fp: fp.stability_score,
                reverse=True
            )
            
            for fp in unmatched_sorted:
                base_name = get_base_name(fp)
                if base_name and base_name not in seen_base_names:
                    unique_fingerprints.append(fp)
                    seen_base_names.add(base_name)
            
            self.matched_fingerprints = unique_fingerprints
            
            # 保存自动匹配建议
            for excel_col, fp, score in match_result['matched']:
                if score >= 90:  # 高可信度
                     fp.stability_score = 100 # 用户信任匹配度，强制设为100分
                     self.auto_mappings[excel_col] = fp
                elif score >= 80:
                     self.auto_mappings[excel_col] = fp
            
            if self.auto_mappings:
                self.master.add_log(f"✅ 自动建议 {len(self.auto_mappings)} 个高质量映射", "success")
                self.master.add_log(f"   您可以在画布中点击确认", "success")

    def highlight_element(self, fingerprint):
        """在浏览器中高亮显示元素（支持多选择器回退+Shadow DOM穿透）"""
        try:
            tab = self._get_target_tab()
            
            # 获取所有可用的选择器
            id_selector = fingerprint.selectors.get('id', '')
            css_selector = fingerprint.selectors.get('css', '')
            xpath = fingerprint.selectors.get('xpath', '')
            elem_id = fingerprint.raw_data.get('id', '')
            shadow_depth = fingerprint.raw_data.get('shadow_depth', 0)
            shadow_host_id = fingerprint.raw_data.get('shadow_host_id', '')
            
            # 构建 JS 高亮脚本（支持多选择器回退+Shadow DOM穿透）
            js_highlight = f"""
            (function() {{
                let el = null;
                
                // Shadow DOM 穿透查找函数
                function findInShadowDOM(hostSelector, targetSelector) {{
                    try {{
                        // 查找所有可能的 shadow host
                        const hosts = document.querySelectorAll('*');
                        for (let host of hosts) {{
                            if (host.shadowRoot) {{
                                // 在 shadowRoot 中查找
                                let found = null;
                                if (targetSelector.startsWith('/')) {{
                                    // XPath 在 shadow DOM 中不太好用，尝试简单选择器
                                    found = host.shadowRoot.querySelector('input, textarea, select');
                                }} else {{
                                    try {{ found = host.shadowRoot.querySelector(targetSelector); }} catch(e) {{}}
                                }}
                                if (found) return found;
                                
                                // 递归查找嵌套的 shadow DOM
                                const nested = host.shadowRoot.querySelectorAll('*');
                                for (let n of nested) {{
                                    if (n.shadowRoot) {{
                                        let innerFound = n.shadowRoot.querySelector('input, textarea, select');
                                        if (innerFound) return innerFound;
                                    }}
                                }}
                            }}
                        }}
                    }} catch(e) {{ console.error('Shadow DOM search error:', e); }}
                    return null;
                }}
                
                // 如果是 Shadow DOM 元素
                if ({shadow_depth} > 0) {{
                    el = findInShadowDOM('{shadow_host_id}', 'input, textarea, select');
                }}
                
                // 尝试1: 通过 ID 选择
                if (!el && '{elem_id}') {{
                    el = document.getElementById('{elem_id}');
                }}
                
                // 尝试2: 通过 ID 选择器
                if (!el && '{id_selector}') {{
                    try {{ el = document.querySelector('{id_selector}'); }} catch(e) {{}}
                }}
                
                // 尝试3: 通过 CSS 选择器
                if (!el && `{css_selector}`) {{
                    try {{ el = document.querySelector(`{css_selector}`); }} catch(e) {{}}
                }}
                
                // 尝试4: 通过 XPath
                if (!el && `{xpath}`) {{
                    try {{
                        let result = document.evaluate(`{xpath}`, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
                        el = result.singleNodeValue;
                    }} catch(e) {{}}
                }}
                
                // 尝试5: 如果都没找到，尝试穿透所有 Shadow DOM
                if (!el) {{
                    el = findInShadowDOM('', 'input, textarea, select');
                }}
                
                if (el) {{
                    // 滚动到元素
                    el.scrollIntoView({{behavior: "smooth", block: "center"}});
                    
                    // 保存原始样式
                    let originalBorder = el.style.border;
                    let originalBg = el.style.backgroundColor;
                    let originalOutline = el.style.outline;
                    let originalBoxShadow = el.style.boxShadow;
                    
                    // 应用苹果风格高亮（纯灰色系）
                    el.style.transition = 'all 0.15s ease-in-out';
                    el.style.border = '1px solid #8E8E93';
                    el.style.outline = '2px solid #636366';
                    el.style.boxShadow = '0 0 0 4px rgba(99, 99, 102, 0.2)';
                    el.style.backgroundColor = 'rgba(142, 142, 147, 0.12)';
                    
                    // 灰色闪烁动画
                    let count = 0;
                    let flashInterval = setInterval(() => {{
                        if (count % 2 === 0) {{
                            el.style.outline = '2px solid #636366';
                            el.style.boxShadow = '0 0 0 4px rgba(99, 99, 102, 0.25)';
                            el.style.backgroundColor = 'rgba(142, 142, 147, 0.15)';
                        }} else {{
                            el.style.outline = '2px solid #AEAEB2';
                            el.style.boxShadow = '0 0 0 4px rgba(174, 174, 178, 0.2)';
                            el.style.backgroundColor = 'rgba(142, 142, 147, 0.08)';
                        }}
                        count++;
                        if (count >= 6) {{
                            clearInterval(flashInterval);
                            // 恢复原始样式
                            setTimeout(() => {{
                                el.style.border = originalBorder;
                                el.style.backgroundColor = originalBg;
                                el.style.outline = originalOutline;
                                el.style.boxShadow = originalBoxShadow;
                            }}, 300);
                        }}
                    }}, 150);
                    
                    return true;
                }}
                return false;
            }})();
            """
            result = tab.run_js(js_highlight)
            if not result:
                print(f"Highlight: 未找到元素 - ID:{elem_id}, XPath:{xpath[:50] if xpath else 'N/A'}...")
        except Exception as e:
            print(f"Highlight error: {e}")

    def _set_perfect_split(self):
        """精准分屏：软件 25% | 浏览器 75%"""
        try:
            sw = self.winfo_screenwidth()
            sh = self.winfo_screenheight()
            
            app_w = int(sw * 0.25)
            app_h = sh - 50
            self.geometry(f"{app_w}x{app_h}+0+0")
            self.update_idletasks()

            browser_w = sw - app_w
            browser_x = app_w
            
            browser_w = sw - app_w
            browser_x = app_w
            
            tab = self._get_target_tab()
            tab.set.window.normal()
            tab.set.activate()
            self._flash_target_page(tab)
            
            tab.set.window.location(browser_x, 0)
            tab.set.window.size(browser_w, sh)
            
            self.master.add_log(f"🎯 目标页已锁定")
        except Exception as e:
            print(f"Split Error: {e}")
    
    def _scan_web_form(self):
        """深度扫描网页表单（智能多维模式）"""
        try:
            self.master.add_log("🔍 启动深度扫描（多维指纹采集）...")
            tab = self._get_target_tab()
            
            # 使用智能分析器
            self.web_fingerprints = SmartFormAnalyzer.deep_scan_page(tab)
            
            if self.web_fingerprints:
                high_stable = sum(1 for f in self.web_fingerprints if f.stability_score >= 80)
                mid_stable = sum(1 for f in self.web_fingerprints if 50 <= f.stability_score < 80)
                low_stable = sum(1 for f in self.web_fingerprints if f.stability_score < 50)
                
                self.master.add_log(f"✅ 发现 {len(self.web_fingerprints)} 个输入字段", "success")
                self.master.add_log(f"   🟢 高稳定性: {high_stable} | 🟡 中等: {mid_stable} | 🔵 低: {low_stable}")
            else:
                self.master.add_log("⚠️ 未找到任何输入字段", "warning")
                self.web_fingerprints = []
        except Exception as e:
            self.master.add_log(f"❌ 扫描失败: {e}", "error")
            import traceback
            traceback.print_exc()
            self.web_fingerprints = []

    def _flash_target_page(self, tab):
        """网页闪烁效果"""
        flash_js = """
        (function() {
            let count = 0;
            const originalBg = document.body.style.backgroundColor;
            const interval = setInterval(() => {
                document.body.style.backgroundColor = count % 2 === 0 ? '#E5E5E5' : originalBg;
                document.body.style.transition = 'all 0.2s';
                count++;
                if (count >= 6) {
                    clearInterval(interval);
                    document.body.style.backgroundColor = originalBg;
                }
            }, 300);
        })();
        """
        try:
            tab.run_js(flash_js)
        except: pass

    def _lock_browser_layout(self):
        """后台监控浏览器位置"""
        while not self.stop_event.is_set():
            time.sleep(2)

    def _setup_layout(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # 主容器
        main_container = ctk.CTkFrame(self, fg_color="transparent")
        main_container.grid(row=0, column=0, sticky="nsew", padx=2, pady=2)
        
        # === 顶部工具栏区域 ===
        toolbar_container = ctk.CTkFrame(main_container, fg_color=ThemeColors.BG_SECONDARY)
        toolbar_container.pack(fill="x", side="top", padx=5, pady=1)
        
        # --- 第一行：操作按钮 ---
        toolbar_row1 = ctk.CTkFrame(toolbar_container, fg_color="transparent")
        toolbar_row1.pack(fill="x", pady=(2, 0))
        
        # 存档/读档
        self.load_btn = AnimatedButton(toolbar_row1, text="📂", 
                                     width=40, height=30,
                                     command=self._load_configuration)
        self.load_btn.pack(side="left", padx=(5, 2), pady=2)
        
        self.save_btn = AnimatedButton(toolbar_row1, text="💾", 
                                     width=40, height=30,
                                     command=self._save_configuration)
        self.save_btn.pack(side="left", padx=2, pady=2)

        # 重新扫描
        self.refresh_btn = AnimatedButton(toolbar_row1, text="🔄重新扫描", 
                                        height=30,
                                        command=self._rescan_form)
        self.refresh_btn.pack(side="left", padx=2, pady=2)

        # 应用建议
        self.auto_map_btn = AnimatedButton(toolbar_row1, text="🤖应用建议", 
                                         height=30,
                                         command=self._apply_auto_mappings)
        self.auto_map_btn.pack(side="left", padx=2, pady=2)
        
        # 清空连线
        self.clear_mapping_btn = AnimatedButton(toolbar_row1, text="🗑清空", 
                                              height=30,
                                              command=self._clear_all_mappings)
        self.clear_mapping_btn.pack(side="left", padx=2, pady=2)

        # --- 第二行：下拉选项 ---
        toolbar_row2 = ctk.CTkFrame(toolbar_container, fg_color="transparent")
        toolbar_row2.pack(fill="x", pady=(0, 2))
        
        # 锚定规则
        ctk.CTkLabel(toolbar_row2, text="锚定规则:", font=(UIStyles.FONT_FAMILY, 12), 
                    text_color=ThemeColors.TEXT_SECONDARY).pack(side="left", padx=(5, 2))
        anchor_values = ["❌按顺序"] + [f"⚓{col}" for col in self.excel_data.columns.tolist()]
        self.anchor_var = ctk.StringVar(value="❌按顺序")
        self.anchor_selector = ctk.CTkOptionMenu(
            toolbar_row2,
            values=anchor_values,
            variable=self.anchor_var,
            fg_color="#FFFFFF",
            text_color="#000000",
            button_color="#E5E5E5",
            button_hover_color="#D0D0D0",
            dropdown_fg_color="#FFFFFF",
            dropdown_text_color="#000000",
            dropdown_hover_color="#E5E5E5",
            font=ctk.CTkFont(family=UIStyles.FONT_FAMILY, size=13),
            dropdown_font=ctk.CTkFont(family=UIStyles.FONT_FAMILY, size=13),
            width=130,
            height=30,
            corner_radius=6
        )
        self.anchor_selector.pack(side="left", padx=2)

        # 录入模式
        ctk.CTkLabel(toolbar_row2, text="录入模式:", font=(UIStyles.FONT_FAMILY, 12), 
                    text_color=ThemeColors.TEXT_SECONDARY).pack(side="left", padx=(15, 2))
        self.mode_var = ctk.StringVar(value="📄单条录入")
        self.mode_selector = ctk.CTkOptionMenu(
            toolbar_row2,
            values=["📄单条录入", "🔢表格批量"],
            variable=self.mode_var,
            fg_color="#FFFFFF",
            text_color="#000000",
            button_color="#E5E5E5",
            button_hover_color="#D0D0D0",
            dropdown_fg_color="#FFFFFF",
            dropdown_text_color="#000000",
            dropdown_hover_color="#E5E5E5",
            font=ctk.CTkFont(family=UIStyles.FONT_FAMILY, size=13),
            dropdown_font=ctk.CTkFont(family=UIStyles.FONT_FAMILY, size=13),
            width=110,
            height=30,
            corner_radius=6
        )
        self.mode_selector.pack(side="left", padx=2)

        # 启动按钮（居中放置在第二行右侧或独立居中）
        self.start_btn = ctk.CTkButton(toolbar_row2, text="🚀启动", 
                                      height=32, width=100,
                                      font=ctk.CTkFont(family=UIStyles.FONT_FAMILY,size=13, weight="bold"),
                                      fg_color=ThemeColors.ACCENT_PRIMARY,
                                      text_color="white",
                                      hover_color=ThemeColors.ACCENT_SECONDARY,
                                      corner_radius=6,
                                      command=self._on_start_click)
        self.start_btn.pack(side="right", padx=10, pady=2)

        # === 智能映射画布 (使用独立Frame避免pack/grid冲突) ===
        canvas_frame = ctk.CTkFrame(main_container, fg_color="transparent")
        canvas_frame.pack(fill="both", expand=True, padx=0, pady=0)
        self._build_mapping_panel(canvas_frame)

    def _build_excel_table(self, parent):
        """构建 Excel 表格区域"""
        parent.grid_columnconfigure(0, weight=1)
        parent.grid_rowconfigure(1, weight=1)

        header = ctk.CTkLabel(parent, text="📊 Excel 数据源", 
                            font=ctk.CTkFont(family=UIStyles.FONT_FAMILY,size=13, weight="bold"),
                            text_color=ThemeColors.ACCENT_PRIMARY)
        header.grid(row=0, column=0, pady=8, sticky="w", padx=10)

        table_frame = ctk.CTkFrame(parent, fg_color="#FFFFFF", border_width=1, border_color=ThemeColors.BORDER)
        table_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 10))
        table_frame.grid_columnconfigure(0, weight=1)
        table_frame.grid_rowconfigure(0, weight=1)

        style = ttk.Style()
        style.theme_use("default")
        style.configure("Treeview", 
                       background="#FFFFFF", 
                       foreground="#000000",
                       fieldbackground="#FFFFFF",
                       borderwidth=0,
                       font=(UIStyles.FONT_FAMILY, 10))
        style.configure("Treeview.Heading", 
                       background=ThemeColors.ACCENT_PRIMARY, 
                       foreground="white",
                       relief="flat")
        style.map("Treeview", background=[('selected', '#F5F5F7')], foreground=[('selected', '#000000')])

        self.tree = ttk.Treeview(table_frame, show="headings")
        self.tree.grid(row=0, column=0, sticky="nsew")

        v_scroll = ttk.Scrollbar(table_frame, orient=VERTICAL, command=self.tree.yview)
        h_scroll = ttk.Scrollbar(table_frame, orient=HORIZONTAL, command=self.tree.xview)
        self.tree.configure(yscroll=v_scroll.set, xscroll=h_scroll.set)
        v_scroll.grid(row=0, column=1, sticky="ns")
        h_scroll.grid(row=1, column=0, sticky="ew")

        cols = self.excel_data.columns.tolist()
        self.tree["columns"] = cols
        for col in cols:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=120, minwidth=80)
        
        for _, row in self.excel_data.iterrows():
            self.tree.insert("", "end", values=row.tolist())

    def _build_mapping_panel(self, parent):
        """构建智能映射画布（只显示匹配的元素）"""
        parent.grid_columnconfigure(0, weight=1)
        parent.grid_rowconfigure(0, weight=1)

        # 创建智能映射画布（传入过滤后的元素列表）
        self.mapping_canvas = MappingCanvas(
            parent,
            excel_columns=self.excel_data.columns.tolist(),
            web_fingerprints=self.matched_fingerprints,  # ← 只显示匹配的
            on_mapping_complete=self._on_canvas_mapping_complete,
            on_element_click=self.highlight_element,  # ← 传入点击回调
            on_add_computed_column=self._open_column_computer # ← 传入添加列回调
        )
        self.mapping_canvas.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
    
    def _on_canvas_mapping_complete(self, mappings):
        """Canvas映射完成回调"""
        self.field_mapping = mappings
        avg_score = sum(fp.stability_score for fp in mappings.values()) / len(mappings) if mappings else 0
        self.master.add_log(f"✅ 已建立 {len(mappings)} 个映射（平均稳定性:{avg_score:.0f}分）", "success")
        if self.auto_mappings:
            self.master.add_log(f"✅ 自动建议 {len(self.auto_mappings)} 个高质量映射", "success")
            self.master.add_log(f"   您可以在画布中点击确认", "success")

    def _apply_auto_mappings(self):
        """应用自动映射建议"""
        if not self.auto_mappings:
            self.master.add_log("⚠️ 没有自动映射建议", "warning")
            return
        
        # 将自动映射应用到field_mapping
        self.field_mapping.update(self.auto_mappings)
        
        # 通知画布绘制连线
        self.mapping_canvas.draw_mappings(self.auto_mappings)
        
        self.master.add_log(f"✅ 已应用 {len(self.auto_mappings)} 个自动映射", "success")
    
    def _rescan_form(self):
        """重新扫描网页表单"""
        self.master.add_log("🔄 重新深度扫描...")
        self._scan_and_match()
        
        # 重新创建映射画布
        mapping_container_parent = self.mapping_canvas.master
        self.mapping_canvas.destroy()
        
        self.mapping_canvas = MappingCanvas(
            mapping_container_parent,
            excel_columns=self.excel_data.columns.tolist(),
            web_fingerprints=self.matched_fingerprints,
            on_mapping_complete=self._on_canvas_mapping_complete,
            on_element_click=self.highlight_element,
            on_add_computed_column=self._open_column_computer
        )
        self.mapping_canvas.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
    
    def _clear_all_mappings(self):
        """清空所有映射"""
        self.field_mapping.clear()
        self.mapping_canvas.clear_all_mappings()
        self.master.add_log("🗑️ 已清空所有映射")

    def _on_start_click(self):
        """点击启动按钮"""
        if not self.field_mapping:
            self.master.add_log("⚠️ 请先建立字段映射", "warning")
            return
        
        # 禁用所有交互按钮
        self.start_btn.configure(state="disabled", text="⏳ 运行中...")
        self.refresh_btn.configure(state="disabled")
        self.clear_mapping_btn.configure(state="disabled")
        if hasattr(self, 'save_btn'): self.save_btn.configure(state="disabled")
        if hasattr(self, 'load_btn'): self.load_btn.configure(state="disabled")
        if hasattr(self, 'anchor_selector'): self.anchor_selector.configure(state="disabled")
        if hasattr(self, 'mode_selector'): self.mode_selector.configure(state="disabled")
        
        # 启动后台线程
        threading.Thread(target=self._execute_fill, daemon=True).start()
    
    def _open_column_computer(self):
        """打开智能列计算器"""
        dialog = ctk.CTkToplevel(self)
        dialog.title("➕ 添加智能计算列")
        dialog.geometry("400x380")
        dialog.attributes("-topmost", True)
        dialog.configure(fg_color="#FFFFFF")
        
        # 1. 分组依据
        ctk.CTkLabel(dialog, text="1. 分组依据 (按谁归类?):", font=(UIStyles.FONT_FAMILY, 13), text_color="#000000").pack(pady=(15,5))
        group_col_var = ctk.StringVar(value=self.excel_data.columns[0])
        ctk.CTkOptionMenu(dialog, values=self.excel_data.columns.tolist(), variable=group_col_var,
                         fg_color="#FFFFFF", text_color="#000000", button_color="#E5E5E5",
                         button_hover_color="#D0D0D0", dropdown_fg_color="#FFFFFF",
                         dropdown_text_color="#000000", dropdown_hover_color="#E5E5E5",
                         font=(UIStyles.FONT_FAMILY, 12), corner_radius=6).pack(pady=5)
        
        # 2. 计算目标
        ctk.CTkLabel(dialog, text="2. 计算目标 (算哪一列?):", font=(UIStyles.FONT_FAMILY, 13), text_color="#000000").pack(pady=(15,5))
        target_col_var = ctk.StringVar(value=self.excel_data.columns[0])
        ctk.CTkOptionMenu(dialog, values=self.excel_data.columns.tolist(), variable=target_col_var,
                         fg_color="#FFFFFF", text_color="#000000", button_color="#E5E5E5",
                         button_hover_color="#D0D0D0", dropdown_fg_color="#FFFFFF",
                         dropdown_text_color="#000000", dropdown_hover_color="#E5E5E5",
                         font=(UIStyles.FONT_FAMILY, 12), corner_radius=6).pack(pady=5)
        
        # 3. 计算方式
        ctk.CTkLabel(dialog, text="3. 计算方式:", font=(UIStyles.FONT_FAMILY, 13), text_color="#000000").pack(pady=(15,5))
        op_map = {"计数 (Count)": "count", "求和 (Sum)": "sum", "平均值 (Mean)": "mean", "最大值 (Max)": "max", "最小值 (Min)": "min"}
        op_var = ctk.StringVar(value="计数 (Count)")
        ctk.CTkOptionMenu(dialog, values=list(op_map.keys()), variable=op_var,
                         fg_color="#FFFFFF", text_color="#000000", button_color="#E5E5E5",
                         button_hover_color="#D0D0D0", dropdown_fg_color="#FFFFFF",
                         dropdown_text_color="#000000", dropdown_hover_color="#E5E5E5",
                         font=(UIStyles.FONT_FAMILY, 12), corner_radius=6).pack(pady=5)
        
        def on_confirm():
            try:
                grp = group_col_var.get()
                tgt = target_col_var.get()
                op_name = op_var.get()
                op = op_map[op_name]
                
                new_col_name = f"{grp}_{op}_{tgt}" if op != 'count' else f"{grp}_出现次数"
                
                # 执行计算
                self.master.add_log(f"🧮 正在计算: 按[{grp}]对[{tgt}]做[{op_name}]...", "info")
                
                # Pandas GroupBy Transform
                if op == 'count':
                   # 对计数来说，Target其实不重要，只要非空即可。
                   # transform('count') 会把每一组的计数填回去
                   self.excel_data[new_col_name] = self.excel_data.groupby(grp)[grp].transform('count')
                else:
                   # 转换数据类型以确保可计算
                   # 尝试转数字
                   try:
                       import pandas as pd
                       temp_df = self.excel_data.copy()
                       temp_df[tgt] = pd.to_numeric(temp_df[tgt], errors='coerce')
                       self.excel_data[new_col_name] = temp_df.groupby(grp)[tgt].transform(op)
                   except Exception as e:
                       self.master.add_log(f"⚠️ 数据转换失败: {e}", "error")
                       return

                self.master.add_log(f"✅ 計算完成! 新增列: [{new_col_name}]", "success")
                
                # 更新画布
                if hasattr(self.mapping_canvas, 'add_new_excel_column'):
                    self.mapping_canvas.add_new_excel_column(new_col_name)
                else:
                    # Fallback: 重绘
                    self._rescan_form() 
                    
                dialog.destroy()
                
            except Exception as e:
                import traceback
                traceback.print_exc()
                self.master.add_log(f"❌ 计算失败: {e}", "error")

        AnimatedButton(dialog, text="✅立即生成", command=on_confirm, height=36).pack(pady=20)

    def _execute_fill(self):
        """在后台线程执行智能填表"""
        try:
            mode_text = self.mode_selector.get()
            
            fill_mode = "single_form"
            if "表格批量" in mode_text:
                fill_mode = "batch_table"
                
            anchor_text = self.anchor_selector.get()
            key_column = None
            if anchor_text and "按顺序" not in anchor_text:
                # 去除前缀 "⚓ " (如果有)
                key_column = anchor_text.replace("⚓ ", "")
            
            # === 1. 最小化窗口，让用户专注浏览器 ===
            self.master.iconify()
            self.master.add_log("📉 窗口已最小化，准备开始填表...")

            self.master.add_log(f"🚀 启动智能填表（自愈模式）")
            if key_column:
                self.master.add_log(f"   ⚓ 使用锚点列: {key_column}")
                
            self.master.add_log(f"   映射字段: {len(self.field_mapping)} 个")
            self.master.add_log(f"   数据行数: {len(self.excel_data)} 行")
            self.master.add_log(f"   完成模式: {mode_text}")
            
            def progress_callback(current, total, message, status):
                if status == "success":
                    self.master.add_log(message, "success")
                elif status == "error":
                    self.master.add_log(message, "error")
                else:
                    self.master.add_log(message)
            
            tab = self._get_target_tab()
            result = SmartFormFiller.fill_form_with_healing(
                tab=tab,
                excel_data=self.excel_data,
                fingerprint_mappings=self.field_mapping,
                fill_mode=fill_mode,
                key_column=key_column,
                progress_callback=progress_callback
            )
            
            self.master.add_log(f"✅ 填表完成! 成功: {result['success']}, 失败: {result['error']}", "success")
            
            # 自愈统计
            if result['healed'] > 0:
                self.master.add_log(f"🩹 自动修复元素: {result['healed']} 个", "success")
                
            if result['errors']:
                self.master.add_log("❌ 错误列表:", "error")
                for err in result['errors'][:5]:
                    self.master.add_log(f"  - {err}", "error")
                if len(result['errors']) > 5:
                    self.master.add_log(f"  ...以及其他 {len(result['errors'])-5} 个错误", "error")
                    
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.master.add_log(f"❌ 执行异常: {e}", "error")
        finally:
            self.start_btn.configure(state="normal", text="🚀 启动")
            self.refresh_btn.configure(state="normal")
            self.clear_mapping_btn.configure(state="normal")
            if hasattr(self, 'save_btn'): self.save_btn.configure(state="normal")
            if hasattr(self, 'load_btn'): self.load_btn.configure(state="normal")
            if hasattr(self, 'anchor_selector'): self.anchor_selector.configure(state="normal")
            if hasattr(self, 'mode_selector'): self.mode_selector.configure(state="normal")
            
            # 恢复窗口
            self.master.deiconify()

    def _save_configuration(self):
        """保存当前配置到文件"""
        filename = ctk.filedialog.asksaveasfilename(
            defaultextension=".json", 
            filetypes=[("JSON Config", "*.json")],
            title="保存填表任务配置"
        )
        if not filename: return
        
        try:
            data = {
                "mode": self.mode_selector.get(),
                "anchor": self.anchor_selector.get(),
                "mappings": {k: v.to_dict() for k, v in self.field_mapping.items()},
                "fingerprints": [fp.to_dict() for fp in self.matched_fingerprints]
            }
            import json
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            self.master.add_log(f"💾 配置已保存: {filename}", "success")
        except Exception as e:
            self.master.add_log(f"❌ 保存失败: {e}", "error")

    def _load_configuration(self):
        """从文件加载配置"""
        filename = ctk.filedialog.askopenfilename(
            filetypes=[("JSON Config", "*.json")],
            title="加载填表任务配置"
        )
        if not filename: return
        
        try:
            import json
            from app.core.element_fingerprint import ElementFingerprint
            
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # 1. 恢复界面选项
            if "mode" in data: self.mode_selector.set(data["mode"])
            if "anchor" in data: self.anchor_selector.set(data["anchor"])
            
            # 2. 恢复指纹库 (避免重新扫描)
            if "fingerprints" in data:
                self.master.add_log("📂 正在恢复网页元素指纹...", "info")
                self.matched_fingerprints = [ElementFingerprint.from_dict(d) for d in data["fingerprints"]]
                
                # 重建画布
                mapping_parent = self.mapping_canvas.master
                self.mapping_canvas.destroy()
                self.mapping_canvas = MappingCanvas(
                    mapping_parent,
                    excel_columns=self.excel_data.columns.tolist(),
                    web_fingerprints=self.matched_fingerprints,
                    on_mapping_complete=self._on_canvas_mapping_complete,
                    on_element_click=self.highlight_element,
                    on_add_computed_column=self._open_column_computer
                )
                self.mapping_canvas.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
            
            # 3. 恢复映射关系
            if "mappings" in data:
                restored_map = {}
                missing_cols = []
                
                for col, fp_data in data["mappings"].items():
                    # 检查Excel列是否存在
                    if col not in self.excel_data.columns:
                        missing_cols.append(col)
                    
                    fp_obj = ElementFingerprint.from_dict(fp_data)
                    
                    # 尝试在现有指纹中找到匹配的对象（为了保持对象引用一致性）
                    found_existing = False
                    for existing in self.matched_fingerprints:
                        # 比较 raw_data 判定是否同一元素
                        if existing.raw_data == fp_obj.raw_data:
                             restored_map[col] = existing
                             found_existing = True
                             break
                    
                    if not found_existing:
                        # 如果没找到（极少情况），就用恢复的对象
                        restored_map[col] = fp_obj
                
                self.field_mapping = restored_map
                
                # 通知画布绘制
                # 注意：如果Excel列缺失，画布可能画不出来线，但我们要尽力画
                self.mapping_canvas.draw_mappings(restored_map)
                
                self.master.add_log(f"✅ 配置加载成功! 恢复 {len(restored_map)} 个映射", "success")
                
                if missing_cols:
                    self.master.add_log(f"⚠️ 注意: 配置文件引用了当前Excel不存在的列: {missing_cols}", "warning")
                    self.master.add_log(f"   请使用'添加计算列'功能重建这些列。", "warning")
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.master.add_log(f"❌ 加载失败: {e}", "error")
        try:
            mode_text = self.mode_selector.get()
            
            fill_mode = "single_form"
            if "表格批量" in mode_text:
                fill_mode = "batch_table"
                
            anchor_text = self.anchor_selector.get()
            key_column = None
            if anchor_text and "按顺序" not in anchor_text:
                # 去除前缀 "⚓ " (如果有)
                key_column = anchor_text.replace("⚓ ", "")
            
            # === 1. 最小化窗口，让用户专注浏览器 ===
            self.master.iconify()
            self.master.add_log("📉 窗口已最小化，准备开始填表...")

            self.master.add_log(f"🚀 启动智能填表（自愈模式）")
            if key_column:
                self.master.add_log(f"   ⚓ 使用锚点列: {key_column}")
                
            self.master.add_log(f"   映射字段: {len(self.field_mapping)} 个")
            self.master.add_log(f"   数据行数: {len(self.excel_data)} 行")
            self.master.add_log(f"   完成模式: {mode_text}")
            
            def progress_callback(current, total, message, status):
                if status == "success":
                    self.master.add_log(message, "success")
                elif status == "error":
                    self.master.add_log(message, "error")
                else:
                    self.master.add_log(message)
            
            tab = self._get_target_tab()
            result = SmartFormFiller.fill_form_with_healing(
                tab=tab,
                excel_data=self.excel_data,
                fingerprint_mappings=self.field_mapping,
                fill_mode=fill_mode,
                key_column=key_column,
                progress_callback=progress_callback
            )
            
            self.master.add_log(f"\n{'='*50}", "success")
            self.master.add_log(f"✅ 填表完成！", "success")
            self.master.add_log(f"📊 总行数: {result['total']}")
            self.master.add_log(f"✔️  成功: {result['success']}", "success")
            
            if result['healed'] > 0:
                self.master.add_log(f"🔧 自愈成功: {result['healed']} 次", "success")
                self.master.add_log(f"   （元素定位失败后自动修复）", "success")
            
            if result['error'] > 0:
                self.master.add_log(f"❌ 失败: {result['error']}", "error")
                self.master.add_log(f"错误详情（前5条）:", "warning")
                for error in result['errors'][:5]:
                    self.master.add_log(f"  - {error}", "warning")
            
            self.master.add_log(f"{'='*50}\n", "success")
            
        except Exception as e:
            self.master.add_log(f"❌ 填表出错: {e}", "error")
            import traceback
            traceback.print_exc()
        finally:
            self.start_btn.configure(state="normal", text="🚀 启动智能填表")
            self.refresh_btn.configure(state="normal")
            self.clear_mapping_btn.configure(state="normal")

    def on_closing(self):
        self.stop_event.set()
        self.destroy()
