"""
元素指纹库 - 多维度识别和自愈选择器
参考：Playwright、Selektra、POM Builder
"""

class ElementFingerprint:
    """元素多维指纹"""
    
    def __init__(self, element_data):
        """
        Args:
            element_data: 从JS扫描返回的原始数据
        """
        self.raw_data = element_data
        
        # 1. 多重选择器路径
        self.selectors = {
            'id': element_data.get('id_selector'),
            'xpath': element_data.get('xpath'),
            'css': element_data.get('css_selector'),
            'aria': element_data.get('aria_selector'),
            'text': element_data.get('text_selector')
        }
        
        # 2. 语义锚点
        self.anchors = {
            'label': element_data.get('label_text', ''),
            'placeholder': element_data.get('placeholder', ''),
            'nearby_text': element_data.get('nearby_text', ''),
            'parent_title': element_data.get('parent_title', ''),
            'visual_label': element_data.get('visual_label', ''),  # 视觉左侧/上方标题
        }
        
        # 3. 元素特征
        self.features = {
            'tag': element_data.get('tagName', ''),
            'type': element_data.get('type', ''),
            'name': element_data.get('name', ''),
            'class': element_data.get('className', ''),
            'position': element_data.get('rect', {})
        }
        
        # 4. 表格位置信息
        self.table_info = {
            'row_index': element_data.get('row_index'),      # 行号 (0-based)
            'col_index': element_data.get('col_index'),      # 列号
            'table_id': element_data.get('table_id'),        # 所属表格标识
            'is_table_cell': element_data.get('is_table_cell', False),
            'table_header': element_data.get('table_header', '')  # 列表头文字
        }
        
        # 5. 坐标信息
        self.rect = element_data.get('rect', {'x': 0, 'y': 0, 'width': 0, 'height': 0})
        
        # 6. 稳定性评分
        self.stability_score = self._calculate_stability()
        
        # 7. 行模式分析（用于表格填充）- 保留兼容
        self.row_pattern = element_data.get('row_pattern', {})
    
    def _calculate_stability(self):
        """
        计算选择器稳定性评分（100分制）
        参考：RPA自愈选择器原理
        """
        score = 0
        
        # ID选择器 - 最稳定（40分）
        if self.selectors.get('id'):
            score += 40
        
        # Name属性（20分）
        if self.features.get('name'):
            score += 20
        
        # ARIA标签（15分）
        if self.selectors.get('aria'):
            score += 15
        
        # Label锚点（15分）
        if self.anchors.get('label'):
            score += 15
        
        # CSS类名（10分，如果不是随机生成）
        css_class = self.features.get('class', '')
        if css_class and not any(x in css_class.lower() for x in ['random', 'gen', 'uuid', 'hash']):
            score += 10
        
        return min(score, 100)
    
    def get_best_selector(self):
        """获取最佳选择器（按稳定性排序）"""
        priority = ['id', 'aria', 'css', 'xpath', 'text']
        for key in priority:
            if self.selectors.get(key):
                return self.selectors[key]
        return self.selectors.get('xpath', '')
    
    def get_fallback_selectors(self):
        """获取备用选择器列表（自愈机制）"""
        result = []
        for key in ['id', 'aria', 'css', 'xpath', 'text']:
            if self.selectors.get(key):
                result.append((key, self.selectors[key]))
        return result
    
    def rebuild_selector_by_anchor(self, nearby_elements):
        """
        通过锚点重建选择器（自愈逻辑）
        
        Args:
            nearby_elements: 当前页面的元素列表
            
        Returns:
            新的选择器字符串
        """
        # 使用label锚点
        if self.anchors.get('label'):
            for elem in nearby_elements:
                if elem.get('label_text') == self.anchors['label']:
                    return elem.get('xpath') or elem.get('css_selector')
        
        # 使用附近文本锚点
        if self.anchors.get('nearby_text'):
            for elem in nearby_elements:
                if elem.get('nearby_text') == self.anchors['nearby_text']:
                    return elem.get('xpath') or elem.get('css_selector')
        
        return None
    
    def matches_pattern(self, other_fingerprint):
        """
        检查是否匹配同一行模式（批量行模式识别）
        
        Args:
            other_fingerprint: 另一个元素指纹
            
        Returns:
            bool: 是否匹配
        """
        if not self.row_pattern or not other_fingerprint.row_pattern:
            return False
        
        # 比较在<tr>中的位置索引
        return (self.row_pattern.get('column_index') == other_fingerprint.row_pattern.get('column_index') and
                self.row_pattern.get('table_id') == other_fingerprint.row_pattern.get('table_id'))
    
    def get_display_name(self):
        """
        生成用户友好的显示名称
        核心原则：用户看到的一定是输入框的"标题"，而不是技术代码
        """
        import re
        
        name = None
        
        # ===== 优先级1：明确的语义标签（最可靠） =====
        
        # 1.1 Label 文本（form label[for] 关联）
        if self.anchors.get('label') and len(self.anchors['label'].strip()) > 0:
            name = self.anchors['label'].strip()
        
        # 1.2 视觉坐标匹配的标题（左侧/上方文本）
        if not name and self.anchors.get('visual_label'):
            name = self.anchors['visual_label'].strip()
        
        # 1.3 表格列表头（table thead）
        if not name and self.table_info.get('table_header'):
            name = self.table_info['table_header'].strip()
        
        # ===== 优先级2：输入框提示信息 =====
        
        # 2.1 Placeholder（输入提示）
        if not name and self.anchors.get('placeholder'):
            placeholder = self.anchors['placeholder'].strip()
            # 过滤常见的无意义 placeholder
            if placeholder and placeholder not in ['请输入', '请选择', '...', '——']:
                name = placeholder
        
        # ===== 优先级3：技术属性转人类语言 =====
        
        if not name:
            # 获取 name 或 id 属性
            raw_name = self.features.get('name', '') or self.raw_data.get('id', '')
            
            if raw_name:
                # 深度清理技术前缀
                cleaned = self._clean_technical_name(raw_name)
                # 翻译为中文
                name = self._translate_to_chinese(cleaned)
        
        # ===== 优先级4：最终回退 =====
        
        if not name or name.strip() == '' or self._is_technical_name(name):
            # 尝试从 nearby_text 获取
            nearby = self.anchors.get('nearby_text', '')
            if nearby and not self._is_technical_name(nearby):
                name = nearby
            else:
                # 生成友好的类型描述
                tag = self.features.get('tag', 'input')
                input_type = self.features.get('type', 'text')
                name = self._get_type_description(tag, input_type)
        
        # ===== 格式化输出 =====
        
        # 表格行号（仅在表格模式有意义时显示）
        row_suffix = ""
        if self.table_info.get('is_table_cell') and self.table_info.get('row_index') is not None:
            row_idx = self.table_info['row_index']
            # 只有第2行及以后才显示行号，第1行通常是模板行
            if row_idx > 0:
                row_suffix = f" [第{row_idx + 1}行]"
        
        # 简洁输出：只显示名称和行号，确保无多余空格
        name = name.strip() if name else ""
        return f"{name}{row_suffix}".strip()
    
    def _clean_technical_name(self, raw_name):
        """深度清理技术命名"""
        import re
        
        if not raw_name:
            return ''
        
        # 移除常见技术前缀
        patterns = [
            r'^row_?\d+_?',           # row_1_, row1_
            r'^col_?\d+_?',           # col_1_, col1_
            r'^field_?\d*_?',         # field_, field_1_
            r'^input_?\d*_?',         # input_, input_1_
            r'^txt_?',                # txt_
            r'^sel_?',                # sel_ (select)
            r'^cb_?',                 # cb_ (checkbox)
            r'^rb_?',                 # rb_ (radio)
            r'^data_?',               # data_
            r'^frm_?',                # frm_ (form)
            r'^ctrl_?',               # ctrl_
            r'^ctl\d+\$?',            # ctl00$, ctl01$
            r'^__\w+__',              # __xxx__
        ]
        
        cleaned = raw_name
        for pattern in patterns:
            cleaned = re.sub(pattern, '', cleaned, flags=re.IGNORECASE)
        
        # 移除尾部数字（如 name_1, name_2）
        cleaned = re.sub(r'_\d+$', '', cleaned)
        
        # 将下划线转空格或保留驼峰
        cleaned = cleaned.replace('_', ' ').strip()
        
        # 处理驼峰命名 (patientName -> patient name)
        cleaned = re.sub(r'([a-z])([A-Z])', r'\1 \2', cleaned)
        
        return cleaned.strip()
    
    def _translate_to_chinese(self, english_name):
        """将英文字段名翻译为中文"""
        if not english_name:
            return ''
        
        # 扩展翻译字典
        translations = {
            # 病人信息
            'patient': '病人', 'patient name': '病人姓名', 'patientname': '病人姓名',
            'name': '姓名', 'fullname': '全名', 'full name': '全名',
            'age': '年龄', 'gender': '性别', 'sex': '性别',
            'birth': '出生日期', 'birthday': '出生日期', 'birthdate': '出生日期',
            'idcard': '身份证号', 'id card': '身份证号', 'identity': '身份证号',
            
            # 联系信息
            'phone': '电话', 'telephone': '电话', 'mobile': '手机',
            'tel': '电话', 'cell': '手机', 'contact': '联系方式',
            'address': '地址', 'addr': '地址', 'home': '家庭住址',
            'email': '邮箱', 'mail': '邮箱',
            
            # 医疗相关
            'doctor': '医生', 'physician': '医师', 'nurse': '护士',
            'department': '科室', 'dept': '科室', 'ward': '病区',
            'bed': '床号', 'room': '房间', 'hospital': '医院',
            'diagnosis': '诊断', 'symptom': '症状', 'symptoms': '症状',
            'treatment': '治疗', 'prescription': '处方',
            'his id': 'HIS单据号', 'hisid': 'HIS单据号',
            'op name': '手术名称', 'opname': '手术名称', 'operation': '手术',
            'insurance': '医保', 'insurance no': '医保卡号',
            
            # 药品/物资
            'drug': '药品', 'drug name': '药品名称', 'drugname': '药品名称',
            'medicine': '药品', 'medication': '药物',
            'spec': '规格', 'specification': '规格',
            'unit': '单位', 'dosage': '剂量',
            'price': '单价', 'unit price': '单价',
            'quantity': '数量', 'qty': '数量', 'amount': '金额',
            'total': '合计', 'subtotal': '小计',
            'consumable': '耗材', 'consumable name': '物资名称',
            
            # 通用字段
            'date': '日期', 'time': '时间', 'datetime': '日期时间',
            'type': '类型', 'category': '分类',
            'status': '状态', 'state': '状态',
            'remark': '备注', 'remarks': '备注', 'note': '备注', 'notes': '备注',
            'description': '描述', 'desc': '描述', 'comment': '说明',
            'id': '编号', 'no': '编号', 'number': '编号', 'code': '代码',
            'title': '标题', 'subject': '主题',
            'content': '内容', 'text': '文本',
            'reason': '原因', 'cause': '原因',
            'result': '结果', 'outcome': '结果',
            'count': '数量', 'num': '数量',
            'emergency': '紧急', 'emergency contact': '紧急联系人',
        }
        
        # 尝试精确匹配
        key = english_name.lower().strip()
        if key in translations:
            return translations[key]
        
        # 尝试部分匹配（单词级别）
        for eng, chn in translations.items():
            if eng in key or key in eng:
                return chn
        
        # 无法翻译时，直接返回清理后的英文（首字母大写）
        return english_name.title()
    
    def _is_technical_name(self, name):
        """判断是否为技术命名（用户看不懂的）"""
        import re
        
        if not name:
            return True
        
        # 包含连续数字或下划线开头
        if re.match(r'^[\d_]', name):
            return True
        
        # 纯数字或只有下划线数字
        if re.match(r'^[\d_]+$', name):
            return True
        
        # 包含 row、col、field 等技术词
        tech_keywords = ['row', 'col', 'field', 'input', 'ctrl', 'ctl', 'frm']
        for kw in tech_keywords:
            if name.lower().startswith(kw) and (len(name) <= len(kw) + 3):
                return True
        
        return False
    
    def _get_type_description(self, tag, input_type):
        """根据元素类型生成友好描述"""
        type_map = {
            'text': '文本输入框',
            'number': '数字输入框',
            'date': '日期选择',
            'time': '时间选择',
            'datetime-local': '日期时间',
            'email': '邮箱输入框',
            'tel': '电话输入框',
            'password': '密码框',
            'checkbox': '复选框',
            'radio': '单选框',
            'select': '下拉选择',
            'select-one': '下拉选择',
            'textarea': '多行文本',
        }
        
        if tag == 'select':
            return '下拉选择'
        if tag == 'textarea':
            return '多行文本'
        
        return type_map.get(input_type, '输入框')
    
    def _get_simple_type_label(self):
        """获取简化的类型标签"""
        tag = self.features.get('tag', 'input')
        input_type = self.features.get('type', 'text')
        
        simple_map = {
            'text': '文本',
            'number': '数字',
            'date': '日期',
            'time': '时间',
            'datetime-local': '日期',
            'email': '邮箱',
            'tel': '电话',
            'password': '密码',
            'checkbox': '勾选',
            'radio': '单选',
            'select': '选择',
            'select-one': '选择',
            'textarea': '文本',
        }
        
        if tag == 'select':
            return '选择'
        if tag == 'textarea':
            return '文本'
        
        return simple_map.get(input_type, '文本')

    def to_dict(self):
        """序列化为字典"""
        return {
            "raw_data": self.raw_data,
            "stability_score": self.stability_score
        }

    @classmethod
    def from_dict(cls, data):
        """从字典反序列化"""
        instance = cls(data["raw_data"])
        # 恢复可能被修改过的分数
        if "stability_score" in data:
            instance.stability_score = data["stability_score"]
        return instance

    def get_selector_for_row(self, target_row_index):
        """
        生成指定行的选择器（用于表格批量填充）
        
        Args:
            target_row_index: 目标行号 (0-based relative to the start row of mapping)
                              Note: Usually if we mapped Row 1, and we want Row 2, index is +1.
                              But here we assume target_row_index is the absolute 1-based index if we can infer it,
                              or relative. Let's stick to: We mapped Row X. We want Row X + offset.
        
        Returns:
            (selector_type, selector_string) or None
        """
        import re
        
        # 1. 尝试处理 XPath (最常用)
        xpath = self.selectors.get('xpath')
        if xpath:
            # 寻找类似 tr[1], tr[2] 的模式
            # 匹配 .../tr[digits]/...
            # 我们假设当前指纹对应的是“第1行”或者“模板行”
            # 如果我们能找到变化的数字，我们就可以替换它
            
            # 策略：找到 XPath 中倒数第一个或第二个带 [] 的数字，通常是行号
            # 例如: //table/tbody/tr[1]/td[2]/input -> tr[1] 是行
            
            # 正则匹配 tr[\d+]
            pattern = re.compile(r'(tr)\[(\d+)\]')
            matches = list(pattern.finditer(xpath))
            
            if matches:
                 # 通常最后一个 tr 是行。但也可能是嵌套表格。
                 # 我们假设修改最后一个 tr 的索引
                 last_match = matches[-1]
                 original_index = int(last_match.group(2))
                 
                 # 计算新的索引
                 # 假设 target_row_index 是增量 (0, 1, 2...)
                 # 新索引 = 原始索引 + 增量
                 new_index = original_index + target_row_index
                 
                 new_xpath = xpath[:last_match.start(2)] + str(new_index) + xpath[last_match.end(2):]
                 return 'xpath', new_xpath
        
        # 2. 尝试处理 ID (e.g. row_1_col_2)
        elem_id = self.selectors.get('id')
        if elem_id:
            # 寻找数字 ID
            # 常见模式: item_0_name, item_1_name
            # 或者: row1col2
            
            # 简单粗暴：找到 ID 中的数字，尝试 + offset
            # 这比较危险，因为 ID 中可能有 unrelated numbers. 
            # 仅当 XPath 失败时尝试
            pass
            
        return None
