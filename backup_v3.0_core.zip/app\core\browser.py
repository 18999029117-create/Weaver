from DrissionPage import ChromiumPage
from app.utils.port_check import PortChecker

class BrowserManager:
    def __init__(self, addr: str = '127.0.0.1:9222'):
        self.addr = addr
        self.page = None

    def connect(self):
        """连接浏览器，如果连接失败会抛出异常"""
        host, port = self.addr.split(':')
        if not PortChecker.is_port_open(int(port), host):
            raise ConnectionError(f"无法连接到 {self.addr}。请确保浏览器已启用调试模式。")
        
        self.page = ChromiumPage(addr_or_opts=self.addr)
        return self.page


    def get_tabs(self):
        """获取所有打开的标签页"""
        if not self.page:
            self.connect()
        
        tabs = []
        for tab_id in self.page.tab_ids:
            try:
                tab = self.page.get_tab(tab_id)
                title = tab.title or "无标题"
                tabs.append({
                    "id": tab_id,
                    "title": title,
                    "url": tab.url
                })
            except:
                continue
        return tabs
