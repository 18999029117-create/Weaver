"""
智能表单分析器 Pro - 空间几何 + JS快照模式
版本: 2.0
优化: 
  - 性能: 全量 JS 执行，一次返回所有元素
  - 精度: 视觉坐标匹配（左侧/上方标题）
  - 深度: 表格 row_index、Shadow DOM、自定义控件
"""
from app.core.element_fingerprint import ElementFingerprint


class SmartFormAnalyzer:
    """
    智能表单分析器 Pro
    采用「空间几何 + JS 快照」模式
    """
    
    @staticmethod
    def get_analysis_js():
        """
        生成高性能 JS 分析脚本
        一次执行返回所有可交互元素的完整信息
        """
        return """
        function scanPage() {
            try {
                // ===== 静默环境设置 (劫持弹窗防止阻塞) =====
                if (!window.__weaverSilentMode) {
                    window.__weaverSilentMode = true;
                    window.__originalAlert = window.alert;
                    window.__originalConfirm = window.confirm;
                    window.__originalPrompt = window.prompt;
                    window.alert = (msg) => { console.log('[Weaver] Alert blocked:', msg); };
                    window.confirm = (msg) => { console.log('[Weaver] Confirm auto-approved:', msg); return true; };
                    window.prompt = (msg, def) => { console.log('[Weaver] Prompt auto-filled:', msg); return def || ''; };
                }
                
                // ===== 加载状态探测 =====
                function detectLoading() {
                    const loaderSelectors = [
                        '.ant-spin-spinning',           // Ant Design 旋转
                        '.ant-spin-container.ant-spin-blur', // Ant Design 模糊遮罩
                        '.el-loading-mask',             // ElementUI 加载遮罩
                        '.el-loading-spinner',          // ElementUI 旋转
                        '.v-loading',                   // Vue Loading
                        '.ivu-spin',                    // iView/View UI
                        '.van-loading',                 // Vant
                        '.weui-loading',                // WeUI
                        '.layui-layer-loading',         // LayUI
                        '.modal-loading',               // 通用
                        '[class*="loading"]:not(input):not(button)', // 模糊匹配
                        '[class*="spinner"]:not(input)',
                        '.skeleton', '.placeholder'     // 骨架屏
                    ];
                    
                    for (let sel of loaderSelectors) {
                        try {
                            let loader = document.querySelector(sel);
                            if (loader && loader.offsetParent !== null) {
                                // 检查是否可见
                                const style = window.getComputedStyle(loader);
                                if (style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0') {
                                    return { status: 'loading', loader: sel };
                                }
                            }
                        } catch(e) {}
                    }
                    
                    // 检查 document.readyState
                    if (document.readyState !== 'complete') {
                        return { status: 'loading', loader: 'document.readyState=' + document.readyState };
                    }
                    
                    return { status: 'ready' };
                }
                
                // 执行加载检测
                const loadStatus = detectLoading();
                if (loadStatus.status === 'loading') {
                    return { status: 'loading', loader: loadStatus.loader, elements: [] };
                }
                
                const results = [];
                
                // ===== 配置 =====
                const INPUT_SELECTORS = [
                    'input:not([type="hidden"]):not([type="button"]):not([type="submit"]):not([type="reset"]):not([type="image"]):not([type="file"])',
                    'select',
                    'textarea',
                    '[contenteditable="true"]',
                    '[role="textbox"]',
                    '[role="combobox"]',
                    '[role="spinbutton"]'
                ].join(',');
                
                // ===== 辅助函数 =====
                
                // 生成稳定的 XPath
                function getXPath(element) {
                    if (!element) return '';
                    if (element.id) {
                        return '//*[@id="' + element.id + '"]';
                    }
                    if (element === document.body) {
                        return '/html/body';
                    }
                    
                    let ix = 0;
                    const siblings = element.parentNode ? element.parentNode.childNodes : [];
                    for (let i = 0; i < siblings.length; i++) {
                        const sibling = siblings[i];
                        if (sibling === element) {
                            const parentPath = getXPath(element.parentNode);
                            const tagName = element.tagName.toLowerCase();
                            return parentPath + '/' + tagName + '[' + (ix + 1) + ']';
                        }
                        if (sibling.nodeType === 1 && sibling.tagName === element.tagName) {
                            ix++;
                        }
                    }
                    return '';
                }
                
                // 生成 CSS 选择器
                function getCSSSelector(element) {
                    if (!element) return '';
                    if (element.id) {
                        return '#' + CSS.escape(element.id);
                    }
                    
                    const parts = [];
                    while (element && element.nodeType === Node.ELEMENT_NODE) {
                        let selector = element.tagName.toLowerCase();
                        if (element.className && typeof element.className === 'string') {
                            const classes = element.className.trim().split(/\\s+/).filter(c => c && !c.match(/^(ng-|v-|_)/));
                            if (classes.length > 0) {
                                selector += '.' + classes.slice(0, 2).map(c => CSS.escape(c)).join('.');
                            }
                        }
                        
                        // 添加 nth-child 确保唯一性
                        const parent = element.parentNode;
                        if (parent) {
                            const siblings = Array.from(parent.children).filter(e => e.tagName === element.tagName);
                            if (siblings.length > 1) {
                                const index = siblings.indexOf(element) + 1;
                                selector += ':nth-of-type(' + index + ')';
                            }
                        }
                        
                        parts.unshift(selector);
                        if (element.id || parts.length > 5) break;
                        element = element.parentNode;
                    }
                    return parts.join(' > ');
                }
                
                // 获取视觉坐标附近的文本（左侧 / 上方）
                function getVisualLabel(element, rect) {
                    if (!rect || rect.width === 0) return '';
                    
                    const searchRadiusX = 250; // 左侧搜索半径 (专家建议250px)
                    const searchRadiusY = 60;  // 上方搜索半径 (专家建议60px)
                    let bestLabel = '';
                    let bestDistance = Infinity;
                    
                    // 收集候选文本节点
                    const walker = document.createTreeWalker(
                        document.body,
                        NodeFilter.SHOW_TEXT,
                        {
                            acceptNode: function(node) {
                                const text = node.textContent.trim();
                                // 过滤空文本和过长文本
                                if (!text || text.length > 50 || text.length < 1) {
                                    return NodeFilter.FILTER_REJECT;
                                }
                                return NodeFilter.FILTER_ACCEPT;
                            }
                        }
                    );
                    
                    let textNode;
                    const candidates = [];
                    
                    while (textNode = walker.nextNode()) {
                        const range = document.createRange();
                        range.selectNodeContents(textNode);
                        const textRect = range.getBoundingClientRect();
                        
                        if (textRect.width === 0 || textRect.height === 0) continue;
                        
                        // 计算文本中心点
                        const textCenterX = textRect.left + textRect.width / 2;
                        const textCenterY = textRect.top + textRect.height / 2;
                        
                        // 元素左侧中心点
                        const elemLeftX = rect.left;
                        const elemCenterY = rect.top + rect.height / 2;
                        
                        // 优先级1: 左侧文本 (在元素左边，且垂直位置接近)
                        if (textCenterX < rect.left && Math.abs(textCenterY - elemCenterY) < 30) {
                            const distance = rect.left - textRect.right;
                            if (distance > 0 && distance < searchRadiusX) {
                                candidates.push({
                                    text: textNode.textContent.trim(),
                                    distance: distance,
                                    priority: 1 // 左侧最优先
                                });
                            }
                        }
                        
                        // 优先级2: 上方文本 (在元素上方，且水平位置接近)
                        if (textCenterY < rect.top && Math.abs(textCenterX - rect.left) < rect.width + 50) {
                            const distance = rect.top - textRect.bottom;
                            if (distance > 0 && distance < searchRadiusY) {
                                candidates.push({
                                    text: textNode.textContent.trim(),
                                    distance: distance,
                                    priority: 2 // 上方其次
                                });
                            }
                        }
                    }
                    
                    // 按优先级和距离排序
                    candidates.sort((a, b) => {
                        if (a.priority !== b.priority) return a.priority - b.priority;
                        return a.distance - b.distance;
                    });
                    
                    if (candidates.length > 0) {
                        bestLabel = candidates[0].text;
                    }
                    
                    return bestLabel;
                }
                
                // 获取表格信息
                function getTableInfo(element) {
                    const info = {
                        is_table_cell: false,
                        row_index: null,
                        col_index: null,
                        table_id: null,
                        header_text: ''
                    };
                    
                    // 向上查找 TD/TH
                    let cell = element.closest('td, th');
                    if (!cell) return info;
                    
                    info.is_table_cell = true;
                    
                    // 获取行
                    const row = cell.closest('tr');
                    if (row) {
                        info.row_index = row.rowIndex;
                        info.col_index = cell.cellIndex;
                    }
                    
                    // 获取表格标识
                    const table = cell.closest('table');
                    if (table) {
                        info.table_id = table.id || table.className || ('table_' + Array.from(document.querySelectorAll('table')).indexOf(table));
                        
                        // 尝试获取表头文字
                        if (info.col_index !== null) {
                            // 先找 thead
                            const thead = table.querySelector('thead');
                            if (thead) {
                                const headerRow = thead.querySelector('tr');
                                if (headerRow) {
                                    const th = headerRow.cells[info.col_index];
                                    if (th) info.header_text = th.textContent.trim();
                                }
                            }
                            
                            // 没有 thead，找第一行
                            if (!info.header_text) {
                                const firstRow = table.querySelector('tr');
                                if (firstRow && firstRow !== row) {
                                    const firstCell = firstRow.cells[info.col_index];
                                    if (firstCell) {
                                        info.header_text = firstCell.textContent.trim();
                                    }
                                }
                            }
                        }
                    }
                    
                    return info;
                }
                
                // 获取关联的 Label 文本
                function getLabelText(element) {
                    // 方法1: 通过 for 属性
                    const id = element.id;
                    if (id) {
                        const label = document.querySelector('label[for="' + CSS.escape(id) + '"]');
                        if (label) return label.textContent.trim();
                    }
                    
                    // 方法2: 包裹在 label 内
                    const parentLabel = element.closest('label');
                    if (parentLabel) {
                        // 获取 label 文本但排除 input 本身的文本
                        const clone = parentLabel.cloneNode(true);
                        const inputs = clone.querySelectorAll('input, select, textarea');
                        inputs.forEach(i => i.remove());
                        return clone.textContent.trim();
                    }
                    
                    // 方法3: aria-label
                    const ariaLabel = element.getAttribute('aria-label');
                    if (ariaLabel) return ariaLabel;
                    
                    // 方法4: aria-labelledby
                    const labelledBy = element.getAttribute('aria-labelledby');
                    if (labelledBy) {
                        const labelElem = document.getElementById(labelledBy);
                        if (labelElem) return labelElem.textContent.trim();
                    }
                    
                    return '';
                }
                
                // ===== 主扫描逻辑 =====
                function scanElements(root, shadowDepth = 0) {
                    const elements = root.querySelectorAll(INPUT_SELECTORS);
                    
                    elements.forEach((el, idx) => {
                        try {
                            // 检查元素是否可见
                            const style = window.getComputedStyle(el);
                            if (style.display === 'none' || style.visibility === 'hidden') {
                                return;
                            }
                            
                            // 获取坐标
                            const rect = el.getBoundingClientRect();
                            
                            // 获取基础属性
                            const tagName = el.tagName.toLowerCase();
                            const inputType = el.type || tagName;
                            const name = el.name || '';
                            const id = el.id || '';
                            const className = el.className || '';
                            const placeholder = el.placeholder || '';
                            const value = el.value || '';
                            
                            // 获取 Label
                            let labelText = getLabelText(el);
                            
                            // 获取表格信息
                            const tableInfo = getTableInfo(el);
                            
                            // 如果表格有表头，优先使用
                            if (tableInfo.header_text && !labelText) {
                                labelText = tableInfo.header_text;
                            }
                            
                            // 如果仍然没有 label，使用视觉坐标匹配
                            let visualLabel = '';
                            if (!labelText) {
                                visualLabel = getVisualLabel(el, rect);
                                if (visualLabel) {
                                    labelText = visualLabel;
                                }
                            }
                            
                            // 最终备选: placeholder -> name -> id
                            if (!labelText) {
                                labelText = placeholder || name || id || '';
                            }
                            
                            // 构造结果对象
                            const data = {
                                index: results.length,
                                tagName: tagName,
                                type: inputType,
                                name: name,
                                id: id,
                                className: typeof className === 'string' ? className : '',
                                placeholder: placeholder,
                                value: value,
                                
                                // 选择器
                                id_selector: id ? '#' + id : null,
                                xpath: getXPath(el),
                                css_selector: getCSSSelector(el),
                                
                                // 语义标签
                                label_text: labelText,
                                visual_label: visualLabel,
                                nearby_text: labelText,
                                
                                // 坐标
                                rect: {
                                    x: Math.round(rect.x),
                                    y: Math.round(rect.y),
                                    width: Math.round(rect.width),
                                    height: Math.round(rect.height)
                                },
                                
                                // 表格信息
                                is_table_cell: tableInfo.is_table_cell,
                                row_index: tableInfo.row_index,
                                col_index: tableInfo.col_index,
                                table_id: tableInfo.table_id,
                                table_header: tableInfo.header_text,
                                
                                // 状态
                                disabled: el.disabled || false,
                                readonly: el.readOnly || false,
                                required: el.required || false,
                                
                                // Shadow DOM 标记
                                shadow_depth: shadowDepth
                            };
                            
                            results.push(data);
                            
                        } catch (e) {
                            // 单个元素失败不影响整体
                            console.warn('Element scan error:', e);
                        }
                    });
                    
                    // Shadow DOM 穿透 (至少2层深度)
                    if (shadowDepth < 2) {
                        const allElements = root.querySelectorAll('*');
                        allElements.forEach(el => {
                            if (el.shadowRoot) {
                                try {
                                    scanElements(el.shadowRoot, shadowDepth + 1);
                                } catch (e) {
                                    console.warn('Shadow DOM scan error:', e);
                                }
                            }
                        });
                    }
                }
                
                // 执行扫描
                scanElements(document);
                
                return results;
                
            } catch (e) {
                return { error: e.toString(), stack: e.stack };
            }
        }
        return scanPage();
        """

    @staticmethod
    def deep_scan_page(tab, max_wait=15, poll_interval=0.8):
        """
        深度扫描网页 - JS 快照模式 + 智能稳定性检测
        
        核心机制:
        - 加载探测: 检测 Ant Design/ElementUI 等加载动画
        - 稳定性算法: 连续2次元素数量一致才认为渲染稳定
        - 静默环境: 自动劫持 alert/confirm 防止阻塞
        
        Args:
            tab: DrissionPage 的 tab 对象
            max_wait: 最大等待时间（秒），默认15秒
            poll_interval: 轮询间隔（秒），默认0.8秒
            
        Returns:
            list[ElementFingerprint]: 元素指纹列表
        """
        import time
        
        print("\n=== 🚀 启动 JS 快照扫描（v3.0 稳定性增强模式） ===")
        
        fingerprints = []
        last_count = -1
        stable_count = 0
        best_result = None
        max_polls = int(max_wait / poll_interval)
        
        try:
            for poll_idx in range(max_polls):
                # 执行 JS 扫描脚本
                if poll_idx == 0:
                    print("🔄 正在执行 JS 批量扫描...")
                
                js_result = tab.run_js(SmartFormAnalyzer.get_analysis_js())
                
                # 检查错误
                if isinstance(js_result, dict):
                    if 'error' in js_result:
                        print(f"⚠️ JS 扫描出错: {js_result['error']}")
                        print("🔄 回退到原生扫描模式...")
                        return SmartFormAnalyzer._fallback_native_scan(tab)
                    
                    # 检查加载状态
                    if js_result.get('status') == 'loading':
                        loader = js_result.get('loader', 'unknown')
                        if poll_idx == 0:
                            print(f"⏳ 检测到加载动画: {loader}，等待页面就绪...")
                        time.sleep(poll_interval)
                        continue
                    
                    # 如果返回的是包含 elements 的对象
                    if 'elements' in js_result:
                        js_result = js_result['elements']
                
                if not isinstance(js_result, list):
                    print(f"⚠️ JS 返回格式异常: {type(js_result)}")
                    time.sleep(poll_interval)
                    continue
                
                current_count = len(js_result)
                
                # 稳定性检测
                if current_count == last_count and current_count > 0:
                    stable_count += 1
                    if stable_count >= 2:
                        # 连续2次数量相同，认为稳定
                        print(f"✅ 页面稳定 (连续 {stable_count} 次检测到 {current_count} 个元素)")
                        best_result = js_result
                        break
                else:
                    stable_count = 0
                    if current_count > 0:
                        best_result = js_result  # 保存最新有效结果
                
                last_count = current_count
                
                if poll_idx > 0 and poll_idx % 3 == 0:
                    print(f"   轮询 {poll_idx+1}/{max_polls}: {current_count} 个元素...")
                
                time.sleep(poll_interval)
            
            # 超时或稳定后处理
            if best_result is None or len(best_result) == 0:
                print("⚠️ 未能获取有效元素，尝试回退...")
                return SmartFormAnalyzer._fallback_native_scan(tab)
            
            print(f"📊 JS 扫描完成，发现 {len(best_result)} 个可交互元素")
            
            # 转换为 ElementFingerprint 对象
            for item in best_result:
                try:
                    fp = ElementFingerprint(item)
                    fingerprints.append(fp)
                except Exception as e:
                    # 静默跳过单个元素错误
                    continue
            
            # 统计信息
            table_count = sum(1 for fp in fingerprints if fp.raw_data.get('is_table_cell'))
            visual_count = sum(1 for fp in fingerprints if fp.raw_data.get('visual_label'))
            shadow_count = sum(1 for fp in fingerprints if fp.raw_data.get('shadow_depth', 0) > 0)
            
            print(f"✅ 深度扫描完成！")
            print(f"   总计: {len(fingerprints)} 个多维指纹")
            print(f"   表格元素: {table_count} 个")
            print(f"   视觉匹配: {visual_count} 个")
            print(f"   Shadow DOM: {shadow_count} 个")
            
            return fingerprints
            
        except Exception as e:
            print(f"❌ JS 扫描严重失败: {e}")
            import traceback
            traceback.print_exc()
            print("🔄 尝试回退到原生扫描...")
            return SmartFormAnalyzer._fallback_native_scan(tab)

    @staticmethod
    def _fallback_native_scan(tab):
        """
        回退的原生扫描模式（兼容旧环境）
        """
        print("🔄 正在执行原生扫描（兼容模式）...")
        
        fingerprints = []
        
        try:
            # 获取所有输入元素
            inputs = tab.eles('xpath://input[not(@type="hidden") and not(@type="button") and not(@type="submit") and not(@type="reset") and not(@type="image") and not(@type="file")]')
            selects = tab.eles('tag:select')
            textareas = tab.eles('tag:textarea')
            
            all_uielems = inputs + selects + textareas
            print(f"   发现 {len(all_uielems)} 个可交互元素")
            
            for idx, el in enumerate(all_uielems):
                try:
                    attrs = el.attrs or {}
                    tag = el.tag
                    elem_type = attrs.get('type', tag)
                    elem_name = attrs.get('name', '')
                    elem_id = attrs.get('id', '')
                    placeholder = attrs.get('placeholder', '')
                    
                    found_label = ""
                    
                    # 表格表头分析
                    try:
                        parent_td = el.parent('tag:td')
                        if parent_td:
                            prev_siblings = parent_td.prevs('tag:td')
                            col_index = len(prev_siblings)
                            
                            table = parent_td.parent('tag:table')
                            if table:
                                th = table.ele(f'xpath:.//thead//tr/th[{col_index + 1}]', timeout=0.1)
                                if th:
                                    found_label = th.text.strip()
                                else:
                                    first_row_th = table.ele(f'xpath:.//tr[1]/th[{col_index + 1}]', timeout=0.1)
                                    if first_row_th:
                                        found_label = first_row_th.text.strip()
                                    else:
                                        first_row_td = table.ele(f'xpath:.//tr[1]/td[{col_index + 1}]', timeout=0.1)
                                        if first_row_td:
                                            found_label = first_row_td.text.strip()
                    except:
                        pass
                    
                    # 常规 Label
                    if not found_label and elem_id:
                        try:
                            label_ele = tab.ele(f'tag:label@for={elem_id}', timeout=0.1)
                            if label_ele:
                                found_label = label_ele.text.strip()
                        except:
                            pass
                    
                    if not found_label:
                        found_label = placeholder or elem_name or elem_id
                    
                    data = {
                        'index': idx,
                        'tagName': tag,
                        'type': elem_type,
                        'name': elem_name,
                        'className': attrs.get('class', ''),
                        'placeholder': placeholder,
                        'id': elem_id,
                        'id_selector': f"#{elem_id}" if elem_id else None,
                        'xpath': el.xpath,
                        'label_text': found_label,
                        'nearby_text': found_label,
                        'rect': {'x': 0, 'y': 0, 'width': 10, 'height': 10}
                    }
                    
                    fp = ElementFingerprint(data)
                    fp.raw_element = el
                    fingerprints.append(fp)
                    
                except Exception as e:
                    continue
            
            print(f"✅ 原生扫描完成！共提取 {len(fingerprints)} 个多维指纹")
            return fingerprints
            
        except Exception as e:
            print(f"❌ 原生扫描失败: {e}")
            import traceback
            traceback.print_exc()
            return []

    @staticmethod
    def auto_fill_with_healing(tab, xpath, value, original_label=None):
        """自愈式填充（保留接口兼容）"""
        pass

    @staticmethod
    def suggest_data_transformation(value, input_type):
        """
        智能数据转换
        Args:
            value: 原始值
            input_type: 目标控件类型 (text, date, checkbox, etc)
        Returns:
            转换后的值
        """
        if value is None:
            return ""
            
        value = str(value).strip()
        
        # 日期处理
        if 'date' in str(input_type).lower():
            if '/' in value:
                return value.replace('/', '-')
            
        return value