# ProcessWindow - 智能版（集成智能匹配）
import customtkinter as ctk
from tkinter import ttk, VERTICAL, HORIZONTAL
import threading
import time

from app.ui.styles import ThemeColors, UIStyles
from app.ui.components import AnimatedButton
from app.core.smart_form_analyzer import SmartFormAnalyzer
from app.core.smart_form_filler import SmartFormFiller
from app.core.smart_matcher import SmartMatcher
from app.ui.mapping_canvas import MappingCanvas
from app.core.pagination_controller import PaginationController
from app.core.fill_progress_manager import FillProgressManager

class ProcessWindow(ctk.CTkToplevel):
    def __init__(self, master, excel_data, browser_tab_id, browser_mgr):
        super().__init__(master)
        
        self.title("Weaver (维沃) v1.0 Beta - 智能填表工作台")
        self.configure(fg_color=ThemeColors.BG_DARK)
        self.attributes("-topmost", True)
        
        self.excel_data = excel_data
        self.browser_tab_id = browser_tab_id
        self.browser_mgr = browser_mgr
        self.stop_event = threading.Event()
        self.abort_event = threading.Event()  # 紧急停止事件
        
        # 智能系统
        self.web_fingerprints = []  # 所有网页元素
        self.matched_fingerprints = []  # 智能匹配后的元素（只显示这些）
        self.field_mapping = {}
        self.auto_mappings = {}  # 自动建议的映射
        
        # 翻页控制
        self.pagination_controller = None
        self.progress_manager = FillProgressManager()
        self.pagination_elements = []  # 检测到的翻页按钮
        self.selected_pagination_btn = None  # 用户选择的翻页按钮
        self.pagination_mode = "manual"  # manual/auto
        
        self._set_perfect_split()
        self._scan_and_match()  # 扫描并智能匹配
        self._setup_layout()
        
        threading.Thread(target=self._lock_browser_layout, daemon=True).start()
        self.protocol("WM_DELETE_WINDOW", self.on_closing)

    def _get_target_tab(self):
        """获取目标标签页对象"""
        try:
            if self.browser_tab_id:
                return self.browser_mgr.page.get_tab(self.browser_tab_id)
        except: pass
        return self.browser_mgr.page

    def _scan_and_match(self):
        """扫描网页并执行智能匹配"""
        # 1. 扫描网页
        self._scan_web_form()
        
        # 1.5 检测翻页按钮
        self._detect_pagination_buttons()
        
        # 2. 智能匹配
        if self.web_fingerprints and len(self.excel_data.columns) > 0:
            self.master.add_log("🎯 执行智能匹配...")
            
            match_result = SmartMatcher.match_fields(
                self.excel_data.columns.tolist(),
                self.web_fingerprints
            )
            
            # --- 去重逻辑（按基础标题去重，不包含行号后缀） ---
            # 原则：用户只需看到每种输入框标题，不需要看到每一行的每个输入框
            
            def get_base_name(fp):
                """获取基础名称（去掉行号后缀，用于去重）"""
                # 优先使用语义标签
                if fp.anchors.get('label'):
                    return fp.anchors['label'].strip()
                if fp.anchors.get('visual_label'):
                    return fp.anchors['visual_label'].strip()
                if fp.table_info.get('table_header'):
                    return fp.table_info['table_header'].strip()
                if fp.anchors.get('placeholder'):
                    return fp.anchors['placeholder'].strip()
                # 回退到 name/id
                return fp.features.get('name', '') or fp.raw_data.get('id', '')
            
            unique_fingerprints = []
            seen_base_names = set()
            
            # 先处理匹配项（优先保留）
            for excel_col, fp, score in match_result['matched']:
                base_name = get_base_name(fp)
                if base_name and base_name not in seen_base_names:
                    unique_fingerprints.append(fp)
                    seen_base_names.add(base_name)
            
            # 再处理未匹配项（按稳定性排序）
            unmatched_sorted = sorted(
                match_result['unmatched_web'],
                key=lambda fp: fp.stability_score,
                reverse=True
            )
            
            for fp in unmatched_sorted:
                base_name = get_base_name(fp)
                if base_name and base_name not in seen_base_names:
                    unique_fingerprints.append(fp)
                    seen_base_names.add(base_name)
            
            self.matched_fingerprints = unique_fingerprints
            
            # 保存自动匹配建议
            for excel_col, fp, score in match_result['matched']:
                if score >= 90:  # 高可信度
                     fp.stability_score = 100 # 用户信任匹配度，强制设为100分
                     self.auto_mappings[excel_col] = fp
                elif score >= 80:
                     self.auto_mappings[excel_col] = fp
            
            if self.auto_mappings:
                self.master.add_log(f"✅ 自动建议 {len(self.auto_mappings)} 个高质量映射", "success")
                self.master.add_log(f"   您可以在画布中点击确认", "success")

    def highlight_element(self, fingerprint):
        """在浏览器中高亮显示元素（支持多选择器回退+Shadow DOM穿透）"""
        try:
            tab = self._get_target_tab()
            
            # 获取所有可用的选择器
            id_selector = fingerprint.selectors.get('id', '')
            css_selector = fingerprint.selectors.get('css', '')
            xpath = fingerprint.selectors.get('xpath', '')
            elem_id = fingerprint.raw_data.get('id', '')
            shadow_depth = fingerprint.raw_data.get('shadow_depth', 0)
            shadow_host_id = fingerprint.raw_data.get('shadow_host_id', '')
            
            # 构建 JS 高亮脚本（支持多选择器回退+Shadow DOM穿透）
            js_highlight = f"""
            (function() {{
                let el = null;
                
                // Shadow DOM 穿透查找函数
                function findInShadowDOM(hostSelector, targetSelector) {{
                    try {{
                        // 查找所有可能的 shadow host
                        const hosts = document.querySelectorAll('*');
                        for (let host of hosts) {{
                            if (host.shadowRoot) {{
                                // 在 shadowRoot 中查找
                                let found = null;
                                if (targetSelector.startsWith('/')) {{
                                    // XPath 在 shadow DOM 中不太好用，尝试简单选择器
                                    found = host.shadowRoot.querySelector('input, textarea, select');
                                }} else {{
                                    try {{ found = host.shadowRoot.querySelector(targetSelector); }} catch(e) {{}}
                                }}
                                if (found) return found;
                                
                                // 递归查找嵌套的 shadow DOM
                                const nested = host.shadowRoot.querySelectorAll('*');
                                for (let n of nested) {{
                                    if (n.shadowRoot) {{
                                        let innerFound = n.shadowRoot.querySelector('input, textarea, select');
                                        if (innerFound) return innerFound;
                                    }}
                                }}
                            }}
                        }}
                    }} catch(e) {{ console.error('Shadow DOM search error:', e); }}
                    return null;
                }}
                
                // 如果是 Shadow DOM 元素
                if ({shadow_depth} > 0) {{
                    el = findInShadowDOM('{shadow_host_id}', 'input, textarea, select');
                }}
                
                // 尝试1: 通过 ID 选择
                if (!el && '{elem_id}') {{
                    el = document.getElementById('{elem_id}');
                }}
                
                // 尝试2: 通过 ID 选择器
                if (!el && '{id_selector}') {{
                    try {{ el = document.querySelector('{id_selector}'); }} catch(e) {{}}
                }}
                
                // 尝试3: 通过 CSS 选择器
                if (!el && `{css_selector}`) {{
                    try {{ el = document.querySelector(`{css_selector}`); }} catch(e) {{}}
                }}
                
                // 尝试4: 通过 XPath
                if (!el && `{xpath}`) {{
                    try {{
                        let result = document.evaluate(`{xpath}`, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
                        el = result.singleNodeValue;
                    }} catch(e) {{}}
                }}
                
                // 尝试5: 如果都没找到，尝试穿透所有 Shadow DOM
                if (!el) {{
                    el = findInShadowDOM('', 'input, textarea, select');
                }}
                
                if (el) {{
                    // 滚动到元素
                    el.scrollIntoView({{behavior: "smooth", block: "center"}});
                    
                    // 保存原始样式
                    let originalBorder = el.style.border;
                    let originalBg = el.style.backgroundColor;
                    let originalOutline = el.style.outline;
                    let originalBoxShadow = el.style.boxShadow;
                    
                    // 应用苹果风格高亮（纯灰色系）
                    el.style.transition = 'all 0.15s ease-in-out';
                    el.style.border = '1px solid #8E8E93';
                    el.style.outline = '2px solid #636366';
                    el.style.boxShadow = '0 0 0 4px rgba(99, 99, 102, 0.2)';
                    el.style.backgroundColor = 'rgba(142, 142, 147, 0.12)';
                    
                    // 灰色闪烁动画
                    let count = 0;
                    let flashInterval = setInterval(() => {{
                        if (count % 2 === 0) {{
                            el.style.outline = '2px solid #636366';
                            el.style.boxShadow = '0 0 0 4px rgba(99, 99, 102, 0.25)';
                            el.style.backgroundColor = 'rgba(142, 142, 147, 0.15)';
                        }} else {{
                            el.style.outline = '2px solid #AEAEB2';
                            el.style.boxShadow = '0 0 0 4px rgba(174, 174, 178, 0.2)';
                            el.style.backgroundColor = 'rgba(142, 142, 147, 0.08)';
                        }}
                        count++;
                        if (count >= 6) {{
                            clearInterval(flashInterval);
                            // 恢复原始样式
                            setTimeout(() => {{
                                el.style.border = originalBorder;
                                el.style.backgroundColor = originalBg;
                                el.style.outline = originalOutline;
                                el.style.boxShadow = originalBoxShadow;
                            }}, 300);
                        }}
                    }}, 150);
                    
                    return true;
                }}
                return false;
            }})();
            """
            result = tab.run_js(js_highlight)
            if not result:
                print(f"Highlight: 未找到元素 - ID:{elem_id}, XPath:{xpath[:50] if xpath else 'N/A'}...")
        except Exception as e:
            print(f"Highlight error: {e}")

    def _set_perfect_split(self):
        """精准分屏：软件 25% | 浏览器 75%"""
        try:
            sw = self.winfo_screenwidth()
            sh = self.winfo_screenheight()
            
            app_w = int(sw * 0.25)
            app_h = sh - 50
            self.geometry(f"{app_w}x{app_h}+0+0")
            self.update_idletasks()

            browser_w = sw - app_w
            browser_x = app_w
            
            browser_w = sw - app_w
            browser_x = app_w
            
            tab = self._get_target_tab()
            tab.set.window.normal()
            tab.set.activate()
            self._flash_target_page(tab)
            
            tab.set.window.location(browser_x, 0)
            tab.set.window.size(browser_w, sh)
            
            self.master.add_log(f"🎯 目标页已锁定")
        except Exception as e:
            print(f"Split Error: {e}")
    
    def _scan_web_form(self):
        """深度扫描网页表单（智能多维模式）"""
        try:
            self.master.add_log("🔍 启动深度扫描（多维指纹采集）...")
            tab = self._get_target_tab()
            
            # 使用智能分析器
            self.web_fingerprints = SmartFormAnalyzer.deep_scan_page(tab)
            
            if self.web_fingerprints:
                high_stable = sum(1 for f in self.web_fingerprints if f.stability_score >= 80)
                mid_stable = sum(1 for f in self.web_fingerprints if 50 <= f.stability_score < 80)
                low_stable = sum(1 for f in self.web_fingerprints if f.stability_score < 50)
                
                self.master.add_log(f"✅ 发现 {len(self.web_fingerprints)} 个输入字段", "success")
                self.master.add_log(f"   🟢 高稳定性: {high_stable} | 🟡 中等: {mid_stable} | 🔵 低: {low_stable}")
            else:
                self.master.add_log("⚠️ 未找到任何输入字段", "warning")
                self.web_fingerprints = []
        except Exception as e:
            self.master.add_log(f"❌ 扫描失败: {e}", "error")
            import traceback
            traceback.print_exc()
            self.web_fingerprints = []

    def _detect_pagination_buttons(self):
        """检测翻页按钮（使用 JS 实现更好的兼容性）"""
        try:
            tab = self._get_target_tab()
            if not tab:
                return
            
            # 使用 JavaScript 检测所有可能的翻页按钮
            js_detect = """
            (function() {
                const keywords = ['下一页', '下一条', 'Next', 'next', '下页', '后一页', 
                                  '翻页', '下一步', '向后', '››', '»', '>>', '>', '→'];
                const results = [];
                
                // 检查所有按钮和链接
                const elements = document.querySelectorAll('button, a, [role="button"], input[type="button"], input[type="submit"], .btn, .page-btn');
                
                elements.forEach((el, idx) => {
                    const text = (el.innerText || el.textContent || el.value || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
                    const className = el.className || '';
                    const id = el.id || '';
                    
                    // 检查文本或类名是否包含翻页关键词
                    let isMatch = false;
                    let matchKeyword = '';
                    
                    for (let kw of keywords) {
                        if (text.includes(kw) || className.toLowerCase().includes('next') || id.toLowerCase().includes('next')) {
                            isMatch = true;
                            matchKeyword = text || kw;
                            break;
                        }
                    }
                    
                    if (isMatch && text.length < 50) {
                        // 构建 XPath
                        let xpath = '';
                        if (el.id) {
                            xpath = `//*[@id="${el.id}"]`;
                        } else {
                            // 构建相对 XPath
                            let path = [];
                            let current = el;
                            while (current && current !== document.body) {
                                let tag = current.tagName.toLowerCase();
                                let parent = current.parentElement;
                                if (parent) {
                                    let siblings = Array.from(parent.children).filter(c => c.tagName === current.tagName);
                                    if (siblings.length > 1) {
                                        let index = siblings.indexOf(current) + 1;
                                        tag += '[' + index + ']';
                                    }
                                }
                                path.unshift(tag);
                                current = parent;
                            }
                            xpath = '//' + path.join('/');
                        }
                        
                        results.push({
                            text: matchKeyword.substring(0, 30),
                            tagName: el.tagName.toLowerCase(),
                            id: el.id || '',
                            className: (el.className || '').substring(0, 50),
                            xpath: xpath
                        });
                    }
                });
                
                return results;
            })();
            """
            
            result = tab.run_js(js_detect)
            
            self.pagination_elements = []
            if result and isinstance(result, list):
                seen_texts = set()
                for item in result:
                    text = item.get('text', '翻页按钮')
                    if text and text not in seen_texts:
                        seen_texts.add(text)
                        self.pagination_elements.append({
                            'text': text,
                            'xpath': item.get('xpath', ''),
                            'id': item.get('id', ''),
                            'tag': item.get('tagName', 'button')
                        })
            
            # 最多保留10个
            self.pagination_elements = self.pagination_elements[:10]
            
            if self.pagination_elements:
                self.master.add_log(f"检测到 {len(self.pagination_elements)} 个翻页按钮")
                for p in self.pagination_elements:
                    self.master.add_log(f"  - {p['text']}")
                
                # 更新下拉框选项
                new_options = ["未指定"] + [p['text'] for p in self.pagination_elements]
                self.pagination_selector.configure(values=new_options)
            else:
                self.master.add_log("未检测到翻页按钮，您可手动指定")
                
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.master.add_log(f"翻页检测异常: {e}")

    def _flash_target_page(self, tab):
        """网页闪烁效果"""
        flash_js = """
        (function() {
            let count = 0;
            const originalBg = document.body.style.backgroundColor;
            const interval = setInterval(() => {
                document.body.style.backgroundColor = count % 2 === 0 ? '#E5E5E5' : originalBg;
                document.body.style.transition = 'all 0.2s';
                count++;
                if (count >= 6) {
                    clearInterval(interval);
                    document.body.style.backgroundColor = originalBg;
                }
            }, 300);
        })();
        """
        try:
            tab.run_js(flash_js)
        except: pass

    def _lock_browser_layout(self):
        """后台监控浏览器位置"""
        while not self.stop_event.is_set():
            time.sleep(2)

    def _setup_layout(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # 主容器
        main_container = ctk.CTkFrame(self, fg_color="transparent")
        main_container.grid(row=0, column=0, sticky="nsew", padx=2, pady=2)
        
        # === 顶部工具栏区域 ===
        toolbar_container = ctk.CTkFrame(main_container, fg_color=ThemeColors.BG_SECONDARY)
        toolbar_container.pack(fill="x", side="top", padx=5, pady=1)
        
        # --- 第一行：操作按钮 ---
        toolbar_row1 = ctk.CTkFrame(toolbar_container, fg_color="transparent")
        toolbar_row1.pack(fill="x", pady=(2, 0))
        
        # 存档/读档
        self.load_btn = AnimatedButton(toolbar_row1, text="📂", 
                                     width=40, height=30,
                                     command=self._load_configuration)
        self.load_btn.pack(side="left", padx=(5, 2), pady=2)
        
        self.save_btn = AnimatedButton(toolbar_row1, text="💾", 
                                     width=40, height=30,
                                     command=self._save_configuration)
        self.save_btn.pack(side="left", padx=2, pady=2)

        # 重新扫描
        self.refresh_btn = AnimatedButton(toolbar_row1, text="🔄重新扫描", 
                                        height=30,
                                        command=self._rescan_form)
        self.refresh_btn.pack(side="left", padx=2, pady=2)

        # 应用建议
        self.auto_map_btn = AnimatedButton(toolbar_row1, text="🤖应用建议", 
                                         height=30,
                                         command=self._apply_auto_mappings)
        self.auto_map_btn.pack(side="left", padx=2, pady=2)
        
        # 清空连线
        self.clear_mapping_btn = AnimatedButton(toolbar_row1, text="🗑清空", 
                                              height=30,
                                              command=self._clear_all_mappings)
        self.clear_mapping_btn.pack(side="left", padx=2, pady=2)

        # --- 第二行：下拉选项 ---
        toolbar_row2 = ctk.CTkFrame(toolbar_container, fg_color="transparent")
        toolbar_row2.pack(fill="x", pady=(0, 2))
        
        # 锚定规则（不带特殊符号，使用纯列名）
        ctk.CTkLabel(toolbar_row2, text="锚定规则:", font=(UIStyles.FONT_FAMILY, 12), 
                    text_color=ThemeColors.TEXT_SECONDARY).pack(side="left", padx=(5, 2))
        anchor_values = ["按顺序录入"] + self.excel_data.columns.tolist()
        self.anchor_var = ctk.StringVar(value="按顺序录入")
        self.anchor_selector = ctk.CTkOptionMenu(
            toolbar_row2,
            values=anchor_values,
            variable=self.anchor_var,
            fg_color="#FFFFFF",
            text_color="#000000",
            button_color="#E5E5E5",
            button_hover_color="#D0D0D0",
            dropdown_fg_color="#FFFFFF",
            dropdown_text_color="#000000",
            dropdown_hover_color="#E5E5E5",
            font=ctk.CTkFont(family=UIStyles.FONT_FAMILY, size=13),
            dropdown_font=ctk.CTkFont(family=UIStyles.FONT_FAMILY, size=13),
            width=130,
            height=30,
            corner_radius=6
        )
        self.anchor_selector.pack(side="left", padx=2)

        # 录入模式
        ctk.CTkLabel(toolbar_row2, text="录入模式:", font=(UIStyles.FONT_FAMILY, 12), 
                    text_color=ThemeColors.TEXT_SECONDARY).pack(side="left", padx=(15, 2))
        self.mode_var = ctk.StringVar(value="单条录入")
        self.mode_selector = ctk.CTkOptionMenu(
            toolbar_row2,
            values=["单条录入", "表格批量"],
            variable=self.mode_var,
            fg_color="#FFFFFF",
            text_color="#000000",
            button_color="#E5E5E5",
            button_hover_color="#D0D0D0",
            dropdown_fg_color="#FFFFFF",
            dropdown_text_color="#000000",
            dropdown_hover_color="#E5E5E5",
            font=ctk.CTkFont(family=UIStyles.FONT_FAMILY, size=13),
            dropdown_font=ctk.CTkFont(family=UIStyles.FONT_FAMILY, size=13),
            width=110,
            height=30,
            corner_radius=6
        )
        self.mode_selector.pack(side="left", padx=2)

        # 启动按钮
        self.start_btn = ctk.CTkButton(toolbar_row2, text="启动", 
                                      height=32, width=100,
                                      font=ctk.CTkFont(family=UIStyles.FONT_FAMILY,size=13, weight="bold"),
                                      fg_color=ThemeColors.ACCENT_PRIMARY,
                                      text_color="white",
                                      hover_color=ThemeColors.ACCENT_SECONDARY,
                                      corner_radius=6,
                                      command=self._on_start_click)
        self.start_btn.pack(side="right", padx=5, pady=2)
        
        # 紧急停止按钮
        self.stop_btn = ctk.CTkButton(toolbar_row2, text="停止", 
                                      height=32, width=80,
                                      font=ctk.CTkFont(family=UIStyles.FONT_FAMILY, size=13),
                                      fg_color="#FFFFFF",
                                      text_color="#000000",
                                      border_width=1,
                                      border_color="#000000",
                                      hover_color="#E5E5E5",
                                      corner_radius=6,
                                      state="disabled",
                                      command=self._on_stop_click)
        self.stop_btn.pack(side="right", padx=2, pady=2)

        # --- 第三行：翻页控制 ---
        toolbar_row3 = ctk.CTkFrame(toolbar_container, fg_color="transparent")
        toolbar_row3.pack(fill="x", pady=(0, 2))
        
        # 翻页按钮选择
        ctk.CTkLabel(toolbar_row3, text="翻页按钮:", font=(UIStyles.FONT_FAMILY, 12), 
                    text_color=ThemeColors.TEXT_SECONDARY).pack(side="left", padx=(5, 2))
        
        # 翻页按钮下拉框
        pagination_options = ["未指定"]
        if hasattr(self, 'pagination_elements') and self.pagination_elements:
            pagination_options += [p['text'] for p in self.pagination_elements]
        
        self.pagination_var = ctk.StringVar(value="未指定")
        self.pagination_selector = ctk.CTkOptionMenu(
            toolbar_row3,
            values=pagination_options,
            variable=self.pagination_var,
            command=self._on_pagination_select,
            fg_color="#FFFFFF",
            text_color="#000000",
            button_color="#E5E5E5",
            button_hover_color="#D0D0D0",
            dropdown_fg_color="#FFFFFF",
            dropdown_text_color="#000000",
            dropdown_hover_color="#E5E5E5",
            font=ctk.CTkFont(family=UIStyles.FONT_FAMILY, size=13),
            dropdown_font=ctk.CTkFont(family=UIStyles.FONT_FAMILY, size=13),
            width=150,
            height=30,
            corner_radius=6
        )
        self.pagination_selector.pack(side="left", padx=2)
        
        # 翻页状态标签
        self.pagination_status = ctk.CTkLabel(toolbar_row3, text="", 
                                             font=(UIStyles.FONT_FAMILY, 11),
                                             text_color="#666666")
        self.pagination_status.pack(side="left", padx=5)
        
        # 翻页模式选择
        ctk.CTkLabel(toolbar_row3, text="翻页模式:", font=(UIStyles.FONT_FAMILY, 12), 
                    text_color=ThemeColors.TEXT_SECONDARY).pack(side="left", padx=(15, 2))
        
        self.pagination_mode_var = ctk.StringVar(value="手动翻页")
        self.pagination_mode_selector = ctk.CTkOptionMenu(
            toolbar_row3,
            values=["手动翻页", "全自动"],
            variable=self.pagination_mode_var,
            command=self._on_pagination_mode_change,
            fg_color="#FFFFFF",
            text_color="#000000",
            button_color="#E5E5E5",
            button_hover_color="#D0D0D0",
            dropdown_fg_color="#FFFFFF",
            dropdown_text_color="#000000",
            dropdown_hover_color="#E5E5E5",
            font=ctk.CTkFont(family=UIStyles.FONT_FAMILY, size=13),
            dropdown_font=ctk.CTkFont(family=UIStyles.FONT_FAMILY, size=13),
            width=110,
            height=30,
            corner_radius=6
        )
        self.pagination_mode_selector.pack(side="left", padx=2)
        
        # 继续录入按钮
        self.continue_btn = ctk.CTkButton(toolbar_row3, text="继续录入", 
                                         height=30, width=100,
                                         font=ctk.CTkFont(family=UIStyles.FONT_FAMILY, size=12),
                                         fg_color="#FFFFFF",
                                         text_color="#000000",
                                         border_width=1,
                                         border_color="#000000",
                                         hover_color="#E5E5E5",
                                         corner_radius=6,
                                         state="disabled",
                                         command=self._on_continue_fill)
        self.continue_btn.pack(side="left", padx=10)
        
        # 进度显示（黑色文字，显示详细信息）
        self.progress_label = ctk.CTkLabel(toolbar_row3, text="就绪", 
                                          font=(UIStyles.FONT_FAMILY, 11),
                                          text_color="#000000")
        self.progress_label.pack(side="right", padx=10)

        # === 智能映射画布 (使用独立Frame避免pack/grid冲突) ===
        canvas_frame = ctk.CTkFrame(main_container, fg_color="transparent")
        canvas_frame.pack(fill="both", expand=True, padx=0, pady=0)
        self._build_mapping_panel(canvas_frame)

    def _build_excel_table(self, parent):
        """构建 Excel 表格区域"""
        parent.grid_columnconfigure(0, weight=1)
        parent.grid_rowconfigure(1, weight=1)

        header = ctk.CTkLabel(parent, text="📊 Excel 数据源", 
                            font=ctk.CTkFont(family=UIStyles.FONT_FAMILY,size=13, weight="bold"),
                            text_color=ThemeColors.ACCENT_PRIMARY)
        header.grid(row=0, column=0, pady=8, sticky="w", padx=10)

        table_frame = ctk.CTkFrame(parent, fg_color="#FFFFFF", border_width=1, border_color=ThemeColors.BORDER)
        table_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 10))
        table_frame.grid_columnconfigure(0, weight=1)
        table_frame.grid_rowconfigure(0, weight=1)

        style = ttk.Style()
        style.theme_use("default")
        style.configure("Treeview", 
                       background="#FFFFFF", 
                       foreground="#000000",
                       fieldbackground="#FFFFFF",
                       borderwidth=0,
                       font=(UIStyles.FONT_FAMILY, 10))
        style.configure("Treeview.Heading", 
                       background=ThemeColors.ACCENT_PRIMARY, 
                       foreground="white",
                       relief="flat")
        style.map("Treeview", background=[('selected', '#F5F5F7')], foreground=[('selected', '#000000')])

        self.tree = ttk.Treeview(table_frame, show="headings")
        self.tree.grid(row=0, column=0, sticky="nsew")

        v_scroll = ttk.Scrollbar(table_frame, orient=VERTICAL, command=self.tree.yview)
        h_scroll = ttk.Scrollbar(table_frame, orient=HORIZONTAL, command=self.tree.xview)
        self.tree.configure(yscroll=v_scroll.set, xscroll=h_scroll.set)
        v_scroll.grid(row=0, column=1, sticky="ns")
        h_scroll.grid(row=1, column=0, sticky="ew")

        cols = self.excel_data.columns.tolist()
        self.tree["columns"] = cols
        for col in cols:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=120, minwidth=80)
        
        for _, row in self.excel_data.iterrows():
            self.tree.insert("", "end", values=row.tolist())

    def _build_mapping_panel(self, parent):
        """构建智能映射画布（只显示匹配的元素）"""
        parent.grid_columnconfigure(0, weight=1)
        parent.grid_rowconfigure(0, weight=1)

        # 创建智能映射画布（传入过滤后的元素列表）
        self.mapping_canvas = MappingCanvas(
            parent,
            excel_columns=self.excel_data.columns.tolist(),
            web_fingerprints=self.matched_fingerprints,  # ← 只显示匹配的
            on_mapping_complete=self._on_canvas_mapping_complete,
            on_element_click=self.highlight_element,  # ← 传入点击回调
            on_add_computed_column=self._open_column_computer # ← 传入添加列回调
        )
        self.mapping_canvas.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
    
    def _on_canvas_mapping_complete(self, mappings):
        """Canvas映射完成回调"""
        self.field_mapping = mappings
        avg_score = sum(fp.stability_score for fp in mappings.values()) / len(mappings) if mappings else 0
        self.master.add_log(f"✅ 已建立 {len(mappings)} 个映射（平均稳定性:{avg_score:.0f}分）", "success")
        if self.auto_mappings:
            self.master.add_log(f"✅ 自动建议 {len(self.auto_mappings)} 个高质量映射", "success")
            self.master.add_log(f"   您可以在画布中点击确认", "success")

    def _apply_auto_mappings(self):
        """应用自动映射建议"""
        if not self.auto_mappings:
            self.master.add_log("⚠️ 没有自动映射建议", "warning")
            return
        
        # 将自动映射应用到field_mapping
        self.field_mapping.update(self.auto_mappings)
        
        # 通知画布绘制连线
        self.mapping_canvas.draw_mappings(self.auto_mappings)
        
        self.master.add_log(f"✅ 已应用 {len(self.auto_mappings)} 个自动映射", "success")
    
    def _rescan_form(self):
        """重新扫描网页表单"""
        self.master.add_log("🔄 重新深度扫描...")
        self._scan_and_match()
        
        # 重新创建映射画布
        mapping_container_parent = self.mapping_canvas.master
        self.mapping_canvas.destroy()
        
        self.mapping_canvas = MappingCanvas(
            mapping_container_parent,
            excel_columns=self.excel_data.columns.tolist(),
            web_fingerprints=self.matched_fingerprints,
            on_mapping_complete=self._on_canvas_mapping_complete,
            on_element_click=self.highlight_element,
            on_add_computed_column=self._open_column_computer
        )
        self.mapping_canvas.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
    
    def _clear_all_mappings(self):
        """清空所有映射"""
        self.field_mapping.clear()
        self.mapping_canvas.clear_all_mappings()
        self.master.add_log("🗑️ 已清空所有映射")

    def _on_pagination_select(self, value):
        """选择翻页按钮"""
        if value == "❌未指定":
            self.selected_pagination_btn = None
            self.pagination_status.configure(text="")
            self.pagination_selector.configure(fg_color="#FFFFFF")
        else:
            # 找到对应的翻页元素
            for p in self.pagination_elements:
                if p['text'] == value:
                    self.selected_pagination_btn = p
                    break
            
            self.pagination_status.configure(text="已指定")
            self.pagination_selector.configure(fg_color="#D0D0D0")
            self.master.add_log(f"已指定翻页按钮: {value}")
    
    def _on_pagination_mode_change(self, value):
        """切换翻页模式"""
        if "全自动" in value:
            self.pagination_mode = "auto"
            self.continue_btn.configure(state="disabled")
            self.master.add_log("翻页模式: 全自动（自动翻页并继续填充）")
        else:
            self.pagination_mode = "manual"
            self.master.add_log("翻页模式: 手动（请手动翻页后点击'继续录入'）")
    
    def _on_continue_fill(self):
        """手动模式下继续录入"""
        if not self.field_mapping:
            self.master.add_log("请先建立字段映射", "warning")
            return
        
        self.master.add_log("继续录入...")
        self.continue_btn.configure(state="disabled")
        
        # 检查是否是锚点模式
        anchor_text = self.anchor_selector.get()
        key_column = None
        if anchor_text and anchor_text != "按顺序录入":
            key_column = anchor_text
        
        if key_column:
            # 锚点模式：需要重新扫描当前页的锚点值
            threading.Thread(target=self._execute_anchor_page_fill, args=(key_column,), daemon=True).start()
        else:
            # 普通模式继续
            self._scan_web_form()
            threading.Thread(target=self._execute_fill_continue, daemon=True).start()
    
    def _execute_anchor_page_fill(self, key_column):
        """锚点模式翻页后重新扫描并填充当前页"""
        try:
            tab = self._get_target_tab()
            
            # 获取已处理的Excel行号
            processed_excel_indices = getattr(self, '_processed_excel_indices', set())
            
            mode_text = self.mode_selector.get()
            fill_mode = "batch_table" if "批量" in mode_text else "single_form"
            
            self.master.add_log(f"正在扫描当前页锚点值...")
            
            # 重新扫描当前页的锚点列
            anchor_fp = self.field_mapping.get(key_column)
            if not anchor_fp:
                self.master.add_log(f"未找到锚点列 {key_column} 的映射", "error")
                return
            
            xpath = anchor_fp.selectors.get('xpath', '')
            if not xpath:
                self.master.add_log("锚点列没有有效的XPath", "error")
                return
            
            import re
            generic_xpath = re.sub(r'tr\[\d+\]', 'tr', xpath)
            
            # 扫描当前页的锚点值
            web_row_map = {}
            elements = tab.eles(f'xpath:{generic_xpath}')
            for idx, ele in enumerate(elements):
                txt = (ele.text or ele.attr('value') or '').strip()
                if txt:
                    web_row_map[txt] = idx
            
            self.master.add_log(f"当前页找到 {len(web_row_map)} 个锚点值")
            
            # 过滤出匹配且未处理的Excel行
            matched_rows = []
            for idx, row in self.excel_data.iterrows():
                if idx in processed_excel_indices:
                    continue  # 跳过已处理的
                excel_key = str(row.get(key_column, '')).strip()
                if excel_key in web_row_map:
                    matched_rows.append({
                        'excel_idx': idx,
                        'excel_data': row,
                        'web_row_idx': web_row_map[excel_key],
                        'anchor_value': excel_key
                    })
            
            matched_rows.sort(key=lambda x: x['web_row_idx'])
            
            if not matched_rows:
                self.master.add_log("当前页没有匹配的数据", "warning")
                self.after(0, lambda: self.continue_btn.configure(state="normal"))
                return
            
            self.master.add_log(f"本页匹配 {len(matched_rows)} 条数据")
            
            # 填充当前页
            total_success = 0
            total_error = 0
            current_idx = 0
            
            while current_idx < len(matched_rows):
                if self.abort_event.is_set():
                    break
                
                match_info = matched_rows[current_idx]
                web_row_idx = match_info['web_row_idx']
                anchor_val = match_info['anchor_value']
                row_data = match_info['excel_data']
                excel_idx = match_info['excel_idx']
                
                self.master.add_log(f"填充: {anchor_val} -> 网页第{web_row_idx+1}行")
                
                success = self._fill_single_anchor_row(tab, row_data, web_row_idx, key_column)
                
                if success:
                    total_success += 1
                    processed_excel_indices.add(excel_idx)
                else:
                    total_error += 1
                
                current_idx += 1
                
                # 单条模式：填1条暂停
                if fill_mode == "single_form" and current_idx < len(matched_rows):
                    self._processed_excel_indices = processed_excel_indices
                    self.master.add_log(f"本页已完成 {current_idx}/{len(matched_rows)}，点击继续")
                    self.after(0, lambda: self.continue_btn.configure(state="normal"))
                    return
            
            # 本页填充完成
            self._processed_excel_indices = processed_excel_indices
            
            self.master.add_log(f"本页填充完成: 成功 {total_success}, 失败 {total_error}")
            self.master.add_log(f"累计已处理: {len(processed_excel_indices)} 行")
            
            # 始终启用继续按钮，让用户决定是否继续翻页
            self.master.add_log("请翻页后点击继续录入，或在完成所有页面后停止")
            self.after(0, lambda: self.continue_btn.configure(state="normal"))
                
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.master.add_log(f"执行异常: {e}", "error")
        finally:
            self.start_btn.configure(state="normal", text="启动")
    
    def _execute_fill_continue(self):
        """从暂停位置继续执行填充"""
        try:
            # 获取暂停时的状态
            if not hasattr(self, '_paused_row_idx'):
                self.master.add_log("⚠️ 没有暂停的任务", "warning")
                return
            
            current_row_idx = self._paused_row_idx
            page_number = getattr(self, '_paused_page_number', 1)
            
            mode_text = self.mode_selector.get()
            fill_mode = "batch_table" if "表格批量" in mode_text else "single_form"
            
            anchor_text = self.anchor_selector.get()
            key_column = None
            if anchor_text and "按顺序" not in anchor_text:
                key_column = anchor_text.replace("⚓ ", "")
            
            tab = self._get_target_tab()
            total_rows = len(self.excel_data)
            
            # 恢复进度管理器
            self.progress_manager.resume()
            
            # 最小化窗口
            self.master.iconify()
            self.master.add_log(f"📄 第 {page_number} 页: 从第 {current_row_idx + 1} 行继续...")
            
            total_success = self.progress_manager.progress.filled_count
            total_error = self.progress_manager.progress.failed_count
            total_healed = 0
            all_errors = []
            
            has_pagination = self.selected_pagination_btn is not None
            is_auto_mode = self.pagination_mode == "auto"
            
            while current_row_idx < total_rows:
                # === 检查紧急停止信号 ===
                if self.abort_event.is_set():
                    self.master.add_log("🛑 用户手动终止，已保存当前进度", "warning")
                    self.progress_manager.pause()
                    break
                
                rows_on_page = self._count_rows_on_current_page(tab)
                if rows_on_page == 0:
                    rows_on_page = 5
                
                end_row_idx = min(current_row_idx + rows_on_page, total_rows)
                page_data = self.excel_data.iloc[current_row_idx:end_row_idx]
                
                self.master.add_log(f"📄 第 {page_number} 页: 填充第 {current_row_idx+1}-{end_row_idx} 行")
                self._update_progress_display(current_row_idx, total_rows, page_number)
                
                def progress_callback(current, total, message, status):
                    if status == "success":
                        self.master.add_log(message, "success")
                    elif status == "error":
                        self.master.add_log(message, "error")
                    else:
                        self.master.add_log(message)
                
                result = SmartFormFiller.fill_form_with_healing(
                    tab=tab,
                    excel_data=page_data.reset_index(drop=True),
                    fingerprint_mappings=self.field_mapping,
                    fill_mode=fill_mode,
                    key_column=key_column,
                    progress_callback=progress_callback
                )
                
                total_success += result['success']
                total_error += result['error']
                total_healed += result['healed']
                all_errors.extend(result['errors'])
                
                self.progress_manager.progress.filled_count = total_success
                self.progress_manager.progress.failed_count = total_error
                self.progress_manager.progress.current_excel_row = end_row_idx + 1
                
                current_row_idx = end_row_idx
                
                if current_row_idx < total_rows:
                    if has_pagination and is_auto_mode:
                        # 全自动翻页
                        self.master.add_log(f"🔄 第 {page_number} 页已完成，自动翻页...")
                        page_turned = self.pagination_controller.click_next_page(wait_after=1.5)
                        
                        if page_turned:
                            page_number += 1
                            self.progress_manager.on_page_turn(page_number)
                            self.pagination_controller.wait_for_page_ready(timeout=5)
                            
                            # 使用 SmartFormAnalyzer 稳定性扫描
                            self.master.add_log("⏳ 正在等待页面渲染稳定...")
                            self.web_fingerprints = SmartFormAnalyzer.deep_scan_page(
                                tab, max_wait=10, poll_interval=0.8
                            )
                            self.master.add_log(f"✅ 页面稳定，检测到 {len(self.web_fingerprints)} 个元素")
                            
                            self._refresh_mappings_for_new_page()
                            self.master.add_log(f"✅ 已翻至第 {page_number} 页，继续填充...")
                        else:
                            self.master.add_log("⚠️ 翻页失败，可能已是最后一页", "warning")
                            break
                    else:
                        # === 手动翻页模式（无论是否配置了翻页按钮）===
                        self.master.add_log(f"⏸️ 第 {page_number} 页已完成 (已填充 {end_row_idx}/{total_rows} 行)")
                        self.master.add_log(f"📢 请手动翻页后点击'继续录入'按钮")
                        self.progress_manager.pause()
                        self._paused_row_idx = current_row_idx
                        self._paused_page_number = page_number + 1
                        self.after(0, lambda: self.continue_btn.configure(state="normal"))
                        self.after(0, lambda: self.stop_btn.configure(state="disabled", text="⏹停止"))
                        # 窗口保持最小化，不弹出
                        return
            
            # 填充完成
            self.progress_manager.complete()
            self.master.add_log(f"{'='*40}")
            self.master.add_log(f"✅ 全部填表完成!", "success")
            self.master.add_log(f"   总计: {total_rows} 行")
            self.master.add_log(f"   成功: {total_success} 行", "success")
            if total_error:
                self.master.add_log(f"   失败: {total_error} 行", "error")
            if total_healed > 0:
                self.master.add_log(f"   🩹 自动修复: {total_healed} 个", "success")
            self.master.add_log(f"{'='*40}")
            
            # 清理暂停状态
            if hasattr(self, '_paused_row_idx'):
                del self._paused_row_idx
            if hasattr(self, '_paused_page_number'):
                del self._paused_page_number
                
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.master.add_log(f"❌ 执行异常: {e}", "error")
        finally:
            self.start_btn.configure(state="normal", text="🚀 启动")
            self.refresh_btn.configure(state="normal")
            self.clear_mapping_btn.configure(state="normal")
            # 不自动弹出窗口
    
    def _update_progress_display(self, current, total, page, fields=None):
        """更新进度显示（详细信息：当前行、总行数、页码、字段数）"""
        try:
            if fields:
                info = f"第{page}页 | 第{current}-{min(current+4, total)}/{total}行 | {fields}字段"
            else:
                info = f"第{page}页 | 第{current}/{total}行"
            self.progress_label.configure(text=info)
        except:
            pass

    def _on_start_click(self):
        """点击启动按钮"""
        if not self.field_mapping:
            self.master.add_log("⚠️ 请先建立字段映射", "warning")
            return
        
        # 清除停止信号
        self.abort_event.clear()
        
        # 禁用所有交互按钮，启用停止按钮
        self.start_btn.configure(state="disabled", text="⏳ 运行中...")
        self.stop_btn.configure(state="normal")  # 启用停止按钮
        self.refresh_btn.configure(state="disabled")
        self.clear_mapping_btn.configure(state="disabled")
        if hasattr(self, 'save_btn'): self.save_btn.configure(state="disabled")
        if hasattr(self, 'load_btn'): self.load_btn.configure(state="disabled")
        if hasattr(self, 'anchor_selector'): self.anchor_selector.configure(state="disabled")
        if hasattr(self, 'mode_selector'): self.mode_selector.configure(state="disabled")
        
        # 启动后台线程
        threading.Thread(target=self._execute_fill, daemon=True).start()
    
    def _on_stop_click(self):
        """紧急停止按钮点击"""
        self.abort_event.set()
        self.master.add_log("🛑 用户手动终止，正在保存进度...", "warning")
        self.stop_btn.configure(state="disabled", text="⏹ 停止中...")
    
    def _open_column_computer(self):
        """打开智能列计算器"""
        dialog = ctk.CTkToplevel(self)
        dialog.title("➕ 添加智能计算列")
        dialog.geometry("400x380")
        dialog.attributes("-topmost", True)
        dialog.configure(fg_color="#FFFFFF")
        
        # 1. 分组依据
        ctk.CTkLabel(dialog, text="1. 分组依据 (按谁归类?):", font=(UIStyles.FONT_FAMILY, 13), text_color="#000000").pack(pady=(15,5))
        group_col_var = ctk.StringVar(value=self.excel_data.columns[0])
        ctk.CTkOptionMenu(dialog, values=self.excel_data.columns.tolist(), variable=group_col_var,
                         fg_color="#FFFFFF", text_color="#000000", button_color="#E5E5E5",
                         button_hover_color="#D0D0D0", dropdown_fg_color="#FFFFFF",
                         dropdown_text_color="#000000", dropdown_hover_color="#E5E5E5",
                         font=(UIStyles.FONT_FAMILY, 12), corner_radius=6).pack(pady=5)
        
        # 2. 计算目标
        ctk.CTkLabel(dialog, text="2. 计算目标 (算哪一列?):", font=(UIStyles.FONT_FAMILY, 13), text_color="#000000").pack(pady=(15,5))
        target_col_var = ctk.StringVar(value=self.excel_data.columns[0])
        ctk.CTkOptionMenu(dialog, values=self.excel_data.columns.tolist(), variable=target_col_var,
                         fg_color="#FFFFFF", text_color="#000000", button_color="#E5E5E5",
                         button_hover_color="#D0D0D0", dropdown_fg_color="#FFFFFF",
                         dropdown_text_color="#000000", dropdown_hover_color="#E5E5E5",
                         font=(UIStyles.FONT_FAMILY, 12), corner_radius=6).pack(pady=5)
        
        # 3. 计算方式
        ctk.CTkLabel(dialog, text="3. 计算方式:", font=(UIStyles.FONT_FAMILY, 13), text_color="#000000").pack(pady=(15,5))
        op_map = {"计数 (Count)": "count", "求和 (Sum)": "sum", "平均值 (Mean)": "mean", "最大值 (Max)": "max", "最小值 (Min)": "min"}
        op_var = ctk.StringVar(value="计数 (Count)")
        ctk.CTkOptionMenu(dialog, values=list(op_map.keys()), variable=op_var,
                         fg_color="#FFFFFF", text_color="#000000", button_color="#E5E5E5",
                         button_hover_color="#D0D0D0", dropdown_fg_color="#FFFFFF",
                         dropdown_text_color="#000000", dropdown_hover_color="#E5E5E5",
                         font=(UIStyles.FONT_FAMILY, 12), corner_radius=6).pack(pady=5)
        
        def on_confirm():
            try:
                grp = group_col_var.get()
                tgt = target_col_var.get()
                op_name = op_var.get()
                op = op_map[op_name]
                
                new_col_name = f"{grp}_{op}_{tgt}" if op != 'count' else f"{grp}_出现次数"
                
                # 执行计算
                self.master.add_log(f"🧮 正在计算: 按[{grp}]对[{tgt}]做[{op_name}]...", "info")
                
                # Pandas GroupBy Transform
                if op == 'count':
                   # 对计数来说，Target其实不重要，只要非空即可。
                   # transform('count') 会把每一组的计数填回去
                   self.excel_data[new_col_name] = self.excel_data.groupby(grp)[grp].transform('count')
                else:
                   # 转换数据类型以确保可计算
                   # 尝试转数字
                   try:
                       import pandas as pd
                       temp_df = self.excel_data.copy()
                       temp_df[tgt] = pd.to_numeric(temp_df[tgt], errors='coerce')
                       self.excel_data[new_col_name] = temp_df.groupby(grp)[tgt].transform(op)
                   except Exception as e:
                       self.master.add_log(f"⚠️ 数据转换失败: {e}", "error")
                       return

                self.master.add_log(f"✅ 計算完成! 新增列: [{new_col_name}]", "success")
                
                # 更新画布
                if hasattr(self.mapping_canvas, 'add_new_excel_column'):
                    self.mapping_canvas.add_new_excel_column(new_col_name)
                else:
                    # Fallback: 重绘
                    self._rescan_form() 
                    
                dialog.destroy()
                
            except Exception as e:
                import traceback
                traceback.print_exc()
                self.master.add_log(f"❌ 计算失败: {e}", "error")

        AnimatedButton(dialog, text="✅立即生成", command=on_confirm, height=36).pack(pady=20)

    def _execute_fill(self):
        """在后台线程执行智能填表（支持分页）"""
        try:
            mode_text = self.mode_selector.get()
            
            fill_mode = "single_form"
            if "表格批量" in mode_text:
                fill_mode = "batch_table"
                
            anchor_text = self.anchor_selector.get()
            key_column = None
            if anchor_text and anchor_text != "按顺序录入":
                # 用户选择了具体的锚定列（就是列名本身）
                key_column = anchor_text
            
            # === 1. 初始化翻页控制器 ===
            tab = self._get_target_tab()
            has_pagination = self.selected_pagination_btn is not None
            is_auto_mode = self.pagination_mode == "auto"
            
            if has_pagination:
                self.pagination_controller = PaginationController(tab)
                # 设置翻页按钮
                btn_info = self.selected_pagination_btn
                if btn_info.get('xpath'):
                    self.pagination_controller.set_next_button(xpath=btn_info['xpath'])
                elif btn_info.get('selector'):
                    self.pagination_controller.set_next_button(selector=btn_info['selector'])
                else:
                    # 尝试通过文本查找
                    self.pagination_controller.set_next_button(selector=f"#next-btn, button:contains('{btn_info['text']}')")
                
                self.master.add_log(f"📄 翻页模式: {'全自动' if is_auto_mode else '手动'}")
            
            # === 1.5 锚点模式预处理：构建匹配映射 ===
            matched_rows = []  # [(excel_row_data, web_row_idx, anchor_value), ...]
            web_row_map = {}   # {anchor_value: web_row_idx}
            
            if key_column and key_column in self.field_mapping:
                self.master.add_log(f"⚓ 锚点模式：正在扫描网页锚点列...")
                
                # 获取锚点列的 fingerprint
                anchor_fp = self.field_mapping[key_column]
                xpath = anchor_fp.selectors.get('xpath', '')
                
                if xpath:
                    import re
                    # 泛化 XPath：将 tr[N] 替换为 tr，以匹配所有行
                    generic_xpath = re.sub(r'tr\[\d+\]', 'tr', xpath)
                    
                    try:
                        # 扫描网页中所有锚点列元素
                        elements = tab.eles(f'xpath:{generic_xpath}')
                        for idx, ele in enumerate(elements):
                            txt = (ele.text or ele.attr('value') or '').strip()
                            if txt:
                                web_row_map[txt] = idx
                        
                        self.master.add_log(f"   ✅ 网页锚点扫描完成，找到 {len(web_row_map)} 个唯一值")
                        
                        # 过滤 Excel 数据：只保留与网页锚点匹配的行
                        for idx, row in self.excel_data.iterrows():
                            excel_key = str(row.get(key_column, '')).strip()
                            if excel_key in web_row_map:
                                matched_rows.append({
                                    'excel_idx': idx,
                                    'excel_data': row,
                                    'web_row_idx': web_row_map[excel_key],
                                    'anchor_value': excel_key
                                })
                        
                        # 按网页行号排序（确保从上到下填充）
                        matched_rows.sort(key=lambda x: x['web_row_idx'])
                        
                        self.master.add_log(f"   ⚓ 匹配成功 {len(matched_rows)} 行（Excel共{len(self.excel_data)}行）")
                        
                        if len(matched_rows) == 0:
                            self.master.add_log("❌ 没有找到匹配的数据！请检查锚点列", "error")
                            return
                            
                    except Exception as e:
                        self.master.add_log(f"❌ 锚点扫描失败: {e}", "error")
                        import traceback
                        traceback.print_exc()
                        return
            
            # === 2. 初始化进度管理器 ===
            # 如果是锚点模式，使用匹配行数；否则使用全部 Excel 行数
            effective_total = len(matched_rows) if matched_rows else len(self.excel_data)
            self.progress_manager.start_new_session(
                excel_file="当前任务",
                total_rows=effective_total,
                anchor_column=key_column or ""
            )
            
            # === 3. 最小化窗口 ===
            self.master.iconify()
            self.master.add_log("📉 窗口已最小化，准备开始填表...")
            self.master.add_log(f"🚀 启动智能填表（自愈模式）")
            if key_column:
                self.master.add_log(f"   ⚓ 使用锚点列: {key_column}")
                self.master.add_log(f"   ⚓ 匹配数据: {len(matched_rows)} 行")
            self.master.add_log(f"   映射字段: {len(self.field_mapping)} 个")
            
            # === 4. 分页填充主循环 ===
            # 如果是锚点模式，使用 matched_rows；否则使用原始 Excel 数据
            if matched_rows:
                # ===== 锚点模式填充 =====
                # 初始化已处理行追踪器（用于跨页追踪）
                self._processed_excel_indices = set()
                
                total_matched = len(matched_rows)
                current_match_idx = 0
                total_success = 0
                total_error = 0
                all_errors = []
                
                while current_match_idx < total_matched:
                    # 检查紧急停止
                    if self.abort_event.is_set():
                        self.master.add_log("🛑 用户手动终止，已保存当前进度", "warning")
                        self.progress_manager.pause()
                        break
                    
                    if fill_mode == "single_form":
                        # 单条录入模式：每次只填一行，然后暂停
                        match_info = matched_rows[current_match_idx]
                        web_row_idx = match_info['web_row_idx']
                        anchor_val = match_info['anchor_value']
                        row_data = match_info['excel_data']
                        
                        self.master.add_log(f"⚓ 正在填充: {anchor_val} → 网页第{web_row_idx+1}行")
                        self._update_progress_display(current_match_idx+1, total_matched, 1, len(self.field_mapping)-1)
                        
                        # 填充这一行
                        success = self._fill_single_anchor_row(tab, row_data, web_row_idx, key_column)
                        
                        if success:
                            total_success += 1
                            self._processed_excel_indices.add(match_info['excel_idx'])
                            self.master.add_log(f"  填充成功", "success")
                        else:
                            total_error += 1
                            all_errors.append(f"锚点 {anchor_val} 填充失败")
                            self.master.add_log(f"  填充失败", "error")
                        
                        current_match_idx += 1
                        
                        # 如果还有更多数据，暂停等待用户继续
                        if current_match_idx < total_matched:
                            self.master.add_log(f"⏸️ 已完成 {current_match_idx}/{total_matched}，请点击'继续录入'")
                            self.progress_manager.pause()
                            self._paused_anchor_idx = current_match_idx
                            self._paused_matched_rows = matched_rows
                            self._paused_key_column = key_column
                            self.after(0, lambda: self.continue_btn.configure(state="normal"))
                            return
                    else:
                        # 批量录入模式：一次填充所有匹配行
                        for match_info in matched_rows[current_match_idx:]:
                            if self.abort_event.is_set():
                                break
                            
                            web_row_idx = match_info['web_row_idx']
                            anchor_val = match_info['anchor_value']
                            row_data = match_info['excel_data']
                            
                            self.master.add_log(f"⚓ 填充: {anchor_val} → 网页第{web_row_idx+1}行")
                            
                            success = self._fill_single_anchor_row(tab, row_data, web_row_idx, key_column)
                            
                            if success:
                                total_success += 1
                            else:
                                total_error += 1
                                all_errors.append(f"锚点 {anchor_val} 填充失败")
                            
                            current_match_idx += 1
                            self._update_progress_display(current_match_idx, total_matched, 1, len(self.field_mapping)-1)
                        
                        # 批量模式下填完所有即结束
                        break
                
                # 锚点模式填充完成
                self.progress_manager.complete()
                self.master.add_log(f"{'='*40}")
                self.master.add_log(f"✅ 锚点填充完成!", "success")
                self.master.add_log(f"   匹配: {total_matched} 行")
                self.master.add_log(f"   成功: {total_success} 行", "success")
                if total_error:
                    self.master.add_log(f"   失败: {total_error} 行", "error")
                self.master.add_log(f"{'='*40}")
                
            else:
                # ===== 普通模式填充（无锚点）=====
                total_rows = len(self.excel_data)
                current_row_idx = 0
                page_number = 1
                total_success = 0
                total_error = 0
                total_healed = 0
                all_errors = []
                
                while current_row_idx < total_rows:
                    # 检查紧急停止信号
                    if self.abort_event.is_set():
                        self.master.add_log("🛑 用户手动终止，已保存当前进度", "warning")
                        self.progress_manager.pause()
                        break
                    
                    # 检测当前页可填充的行数
                    rows_on_page = self._count_rows_on_current_page(tab)
                    if rows_on_page == 0:
                        rows_on_page = 5
                    
                    # 计算本页要填充的数据
                    end_row_idx = min(current_row_idx + rows_on_page, total_rows)
                    page_data = self.excel_data.iloc[current_row_idx:end_row_idx]
                    
                    self.master.add_log(f"📄 第 {page_number} 页: 填充第 {current_row_idx+1}-{end_row_idx} 行")
                    self._update_progress_display(current_row_idx, total_rows, page_number)
                    
                    def progress_callback(current, total, message, status):
                        if status == "success":
                            self.master.add_log(message, "success")
                        elif status == "error":
                            self.master.add_log(message, "error")
                        else:
                            self.master.add_log(message)
                    
                    # 执行本页填充
                    result = SmartFormFiller.fill_form_with_healing(
                        tab=tab,
                        excel_data=page_data.reset_index(drop=True),
                        fingerprint_mappings=self.field_mapping,
                        fill_mode=fill_mode,
                        key_column=None,  # 普通模式不使用锚点
                        progress_callback=progress_callback
                    )
                    
                    # 累积统计
                    total_success += result['success']
                    total_error += result['error']
                    total_healed += result['healed']
                    all_errors.extend(result['errors'])
                    
                    # 更新进度管理器
                    self.progress_manager.progress.filled_count = total_success
                    self.progress_manager.progress.failed_count = total_error
                    self.progress_manager.progress.current_excel_row = end_row_idx + 1
                    
                    # 移动到下一批数据
                    current_row_idx = end_row_idx
                    
                    # 检查是否还有更多数据需要翻页
                    if current_row_idx < total_rows:
                        if has_pagination and is_auto_mode:
                            # === 全自动翻页 ===
                            self.master.add_log(f"🔄 第 {page_number} 页已完成，自动翻页...")
                            
                            # 点击翻页按钮
                            page_turned = self.pagination_controller.click_next_page(wait_after=1.5)
                            
                            if page_turned:
                                page_number += 1
                                self.progress_manager.on_page_turn(page_number)
                                
                                # 等待页面加载完成
                                self.pagination_controller.wait_for_page_ready(timeout=5)
                                
                                # === 使用 SmartFormAnalyzer 稳定性扫描 ===
                                self.master.add_log("⏳ 正在等待页面渲染稳定...")
                                self.web_fingerprints = SmartFormAnalyzer.deep_scan_page(
                                    tab, max_wait=10, poll_interval=0.8
                                )
                                self.master.add_log(f"✅ 页面稳定，检测到 {len(self.web_fingerprints)} 个元素")
                                
                                # 重新执行智能匹配，更新映射
                                self._refresh_mappings_for_new_page()
                                
                                self.master.add_log(f"✅ 已翻至第 {page_number} 页，继续填充...")
                            else:
                                self.master.add_log("⚠️ 翻页失败，可能已是最后一页", "warning")
                                break
                        else:
                            # === 手动翻页模式 ===
                            self.master.add_log(f"⏸️ 第 {page_number} 页已完成 (已填充 {end_row_idx}/{total_rows} 行)")
                            self.master.add_log(f"📢 请手动翻页后点击'继续录入'按钮")
                            self.progress_manager.pause()
                            
                            # 保存当前进度状态
                            self._paused_row_idx = current_row_idx
                            self._paused_page_number = page_number + 1
                            
                            # 启用继续按钮
                            self.after(0, lambda: self.continue_btn.configure(state="normal"))
                            self.after(0, lambda: self.stop_btn.configure(state="disabled", text="⏹停止"))
                            
                            # 退出循环，等待用户手动翻页
                            return
                
                # === 5. 普通模式填充完成 ===
            self.progress_manager.complete()
            self.master.add_log(f"{'='*40}")
            self.master.add_log(f"✅ 全部填表完成!", "success")
            self.master.add_log(f"   总计: {total_rows} 行")
            self.master.add_log(f"   成功: {total_success} 行", "success")
            self.master.add_log(f"   失败: {total_error} 行" if total_error else "   失败: 0 行")
            if total_healed > 0:
                self.master.add_log(f"   🩹 自动修复: {total_healed} 个", "success")
            self.master.add_log(f"{'='*40}")
                
            if all_errors:
                self.master.add_log("❌ 错误列表:", "error")
                for err in all_errors[:5]:
                    self.master.add_log(f"  - {err}", "error")
                if len(all_errors) > 5:
                    self.master.add_log(f"  ...以及其他 {len(all_errors)-5} 个错误", "error")
                    
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.master.add_log(f"❌ 执行异常: {e}", "error")
        finally:
            self.start_btn.configure(state="normal", text="🚀 启动")
            self.stop_btn.configure(state="disabled", text="⏹停止")  # 重置停止按钮
            self.refresh_btn.configure(state="normal")
            self.clear_mapping_btn.configure(state="normal")
            if hasattr(self, 'save_btn'): self.save_btn.configure(state="normal")
            if hasattr(self, 'load_btn'): self.load_btn.configure(state="normal")
            if hasattr(self, 'anchor_selector'): self.anchor_selector.configure(state="normal")
            if hasattr(self, 'mode_selector'): self.mode_selector.configure(state="normal")
            # 不自动弹出窗口
    
    def _count_rows_on_current_page(self, tab):
        """检测当前页面的表格行数"""
        try:
            js = """
            (() => {
                // 方法1: 查找表格tbody中的行
                let rows = document.querySelectorAll('table tbody tr');
                if (rows.length > 0) return rows.length;
                
                // 方法2: 查找包含输入框的行
                let inputGroups = document.querySelectorAll('.form-row, .data-row, [class*="row"]');
                if (inputGroups.length > 0) return inputGroups.length;
                
                // 方法3: 计算输入框数量除以映射字段数
                let inputs = document.querySelectorAll('input:not([type="hidden"]), select, textarea');
                return inputs.length;
            })();
            """
            result = tab.run_js(js)
            return int(result) if result else 5
        except:
            return 5  # 默认5行
    
    def _refresh_mappings_for_new_page(self):
        """翻页后刷新映射关系"""
        # 原有映射的Excel列名不变，但需要更新fingerprint指向新页面的元素
        # 由于 fingerprint 中的选择器（尤其是 XPath）可能是相对固定的，
        # 对于表格模式，每页的结构应该相同，所以选择器仍然有效
        # 这里主要是触发重新扫描，让 web_fingerprints 更新
        pass
    
    def _fill_single_anchor_row(self, tab, row_data, web_row_idx, key_column):
        """
        填充单行锚点匹配的数据
        
        Args:
            tab: 浏览器标签页
            row_data: Excel 行数据 (pandas Series)
            web_row_idx: 目标网页行索引 (0-based)
            key_column: 锚点列名（跳过填充此列）
            
        Returns:
            bool: 是否成功填充
        """
        try:
            filled_count = 0
            for excel_col, fingerprint in self.field_mapping.items():
                # 跳过锚点列本身
                if excel_col == key_column:
                    continue
                
                # 获取 Excel 值
                cell_value = row_data.get(excel_col)
                if cell_value is None or (isinstance(cell_value, float) and str(cell_value) == 'nan'):
                    continue
                cell_value = str(cell_value).strip()
                if not cell_value:
                    continue
                
                try:
                    # 获取目标行的动态选择器
                    dynamic_selector = fingerprint.get_selector_for_row(web_row_idx)
                    
                    if dynamic_selector:
                        sel_type, sel_str = dynamic_selector
                        if sel_type == 'xpath':
                            ele = tab.ele(f'xpath:{sel_str}', timeout=0.5)
                        else:
                            ele = tab.ele(sel_str, timeout=0.5)
                        
                        if ele:
                            ele.clear()
                            ele.input(cell_value)
                            filled_count += 1
                        else:
                            print(f"   ⚠️ 未找到元素: {excel_col}")
                    else:
                        # 没有动态选择器，尝试使用原始选择器
                        success = SmartFormFiller._fill_with_fallback(tab, fingerprint, cell_value)
                        if success:
                            filled_count += 1
                            
                except Exception as e:
                    print(f"   ⚠️ 填充 {excel_col} 失败: {e}")
            
            return filled_count > 0
            
        except Exception as e:
            print(f"_fill_single_anchor_row 异常: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _execute_anchor_fill_continue(self):
        """从暂停位置继续锚点模式填充"""
        try:
            if not hasattr(self, '_paused_anchor_idx') or not hasattr(self, '_paused_matched_rows'):
                self.master.add_log("没有暂停的锚点任务", "warning")
                return
            
            current_match_idx = self._paused_anchor_idx
            matched_rows = self._paused_matched_rows
            key_column = getattr(self, '_paused_key_column', None)
            
            tab = self._get_target_tab()
            total_matched = len(matched_rows)
            
            mode_text = self.mode_selector.get()
            fill_mode = "batch_table" if "批量" in mode_text else "single_form"
            
            self.master.add_log(f"恢复锚点填充，从第 {current_match_idx + 1} 条继续")
            
            total_success = 0
            total_error = 0
            
            while current_match_idx < total_matched:
                if self.abort_event.is_set():
                    self.master.add_log("用户手动终止，已保存当前进度", "warning")
                    break
                
                if fill_mode == "single_form":
                    # 单条模式：填一行就暂停
                    match_info = matched_rows[current_match_idx]
                    web_row_idx = match_info['web_row_idx']
                    anchor_val = match_info['anchor_value']
                    row_data = match_info['excel_data']
                    
                    self.master.add_log(f"正在填充: {anchor_val} -> 网页第{web_row_idx+1}行")
                    
                    success = self._fill_single_anchor_row(tab, row_data, web_row_idx, key_column)
                    
                    if success:
                        total_success += 1
                        self.master.add_log(f"  填充成功", "success")
                    else:
                        total_error += 1
                        self.master.add_log(f"  填充失败", "error")
                    
                    current_match_idx += 1
                    
                    if current_match_idx < total_matched:
                        self.master.add_log(f"已完成 {current_match_idx}/{total_matched}，请点击'继续录入'")
                        self._paused_anchor_idx = current_match_idx
                        self.after(0, lambda: self.continue_btn.configure(state="normal"))
                        return
                else:
                    # 批量模式：填完所有
                    for match_info in matched_rows[current_match_idx:]:
                        if self.abort_event.is_set():
                            break
                        
                        web_row_idx = match_info['web_row_idx']
                        anchor_val = match_info['anchor_value']
                        row_data = match_info['excel_data']
                        
                        success = self._fill_single_anchor_row(tab, row_data, web_row_idx, key_column)
                        
                        if success:
                            total_success += 1
                        else:
                            total_error += 1
                        
                        current_match_idx += 1
                    break
            
            # 填充完成，清理状态
            self.progress_manager.complete()
            self.master.add_log(f"{'='*30}")
            self.master.add_log(f"锚点填充完成!", "success")
            self.master.add_log(f"  成功: {total_success} 行")
            if total_error:
                self.master.add_log(f"  失败: {total_error} 行", "error")
            self.master.add_log(f"{'='*30}")
            
            # 清理暂停状态
            if hasattr(self, '_paused_anchor_idx'):
                del self._paused_anchor_idx
            if hasattr(self, '_paused_matched_rows'):
                del self._paused_matched_rows
            if hasattr(self, '_paused_key_column'):
                del self._paused_key_column
                
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.master.add_log(f"锚点继续执行异常: {e}", "error")
        finally:
            self.start_btn.configure(state="normal", text="启动")
            self.refresh_btn.configure(state="normal")

    def _save_configuration(self):
        """保存当前配置到文件"""
        filename = ctk.filedialog.asksaveasfilename(
            defaultextension=".json", 
            filetypes=[("JSON Config", "*.json")],
            title="保存填表任务配置"
        )
        if not filename: return
        
        try:
            data = {
                "mode": self.mode_selector.get(),
                "anchor": self.anchor_selector.get(),
                "mappings": {k: v.to_dict() for k, v in self.field_mapping.items()},
                "fingerprints": [fp.to_dict() for fp in self.matched_fingerprints]
            }
            import json
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            self.master.add_log(f"💾 配置已保存: {filename}", "success")
        except Exception as e:
            self.master.add_log(f"❌ 保存失败: {e}", "error")

    def _load_configuration(self):
        """从文件加载配置"""
        filename = ctk.filedialog.askopenfilename(
            filetypes=[("JSON Config", "*.json")],
            title="加载填表任务配置"
        )
        if not filename: return
        
        try:
            import json
            from app.core.element_fingerprint import ElementFingerprint
            
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # 1. 恢复界面选项
            if "mode" in data: self.mode_selector.set(data["mode"])
            if "anchor" in data: self.anchor_selector.set(data["anchor"])
            
            # 2. 恢复指纹库 (避免重新扫描)
            if "fingerprints" in data:
                self.master.add_log("📂 正在恢复网页元素指纹...", "info")
                self.matched_fingerprints = [ElementFingerprint.from_dict(d) for d in data["fingerprints"]]
                
                # 重建画布
                mapping_parent = self.mapping_canvas.master
                self.mapping_canvas.destroy()
                self.mapping_canvas = MappingCanvas(
                    mapping_parent,
                    excel_columns=self.excel_data.columns.tolist(),
                    web_fingerprints=self.matched_fingerprints,
                    on_mapping_complete=self._on_canvas_mapping_complete,
                    on_element_click=self.highlight_element,
                    on_add_computed_column=self._open_column_computer
                )
                self.mapping_canvas.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
            
            # 3. 恢复映射关系
            if "mappings" in data:
                restored_map = {}
                missing_cols = []
                
                for col, fp_data in data["mappings"].items():
                    # 检查Excel列是否存在
                    if col not in self.excel_data.columns:
                        missing_cols.append(col)
                    
                    fp_obj = ElementFingerprint.from_dict(fp_data)
                    
                    # 尝试在现有指纹中找到匹配的对象（为了保持对象引用一致性）
                    found_existing = False
                    for existing in self.matched_fingerprints:
                        # 比较 raw_data 判定是否同一元素
                        if existing.raw_data == fp_obj.raw_data:
                             restored_map[col] = existing
                             found_existing = True
                             break
                    
                    if not found_existing:
                        # 如果没找到（极少情况），就用恢复的对象
                        restored_map[col] = fp_obj
                
                self.field_mapping = restored_map
                
                # 通知画布绘制
                # 注意：如果Excel列缺失，画布可能画不出来线，但我们要尽力画
                self.mapping_canvas.draw_mappings(restored_map)
                
                self.master.add_log(f"✅ 配置加载成功! 恢复 {len(restored_map)} 个映射", "success")
                
                if missing_cols:
                    self.master.add_log(f"⚠️ 注意: 配置文件引用了当前Excel不存在的列: {missing_cols}", "warning")
                    self.master.add_log(f"   请使用'添加计算列'功能重建这些列。", "warning")
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.master.add_log(f"❌ 加载失败: {e}", "error")
        try:
            mode_text = self.mode_selector.get()
            
            fill_mode = "single_form"
            if "表格批量" in mode_text:
                fill_mode = "batch_table"
                
            anchor_text = self.anchor_selector.get()
            key_column = None
            if anchor_text and "按顺序" not in anchor_text:
                # 去除前缀 "⚓ " (如果有)
                key_column = anchor_text.replace("⚓ ", "")
            
            # === 1. 最小化窗口，让用户专注浏览器 ===
            self.master.iconify()
            self.master.add_log("📉 窗口已最小化，准备开始填表...")

            self.master.add_log(f"🚀 启动智能填表（自愈模式）")
            if key_column:
                self.master.add_log(f"   ⚓ 使用锚点列: {key_column}")
                
            self.master.add_log(f"   映射字段: {len(self.field_mapping)} 个")
            self.master.add_log(f"   数据行数: {len(self.excel_data)} 行")
            self.master.add_log(f"   完成模式: {mode_text}")
            
            def progress_callback(current, total, message, status):
                if status == "success":
                    self.master.add_log(message, "success")
                elif status == "error":
                    self.master.add_log(message, "error")
                else:
                    self.master.add_log(message)
            
            tab = self._get_target_tab()
            result = SmartFormFiller.fill_form_with_healing(
                tab=tab,
                excel_data=self.excel_data,
                fingerprint_mappings=self.field_mapping,
                fill_mode=fill_mode,
                key_column=key_column,
                progress_callback=progress_callback
            )
            
            self.master.add_log(f"\n{'='*50}", "success")
            self.master.add_log(f"✅ 填表完成！", "success")
            self.master.add_log(f"📊 总行数: {result['total']}")
            self.master.add_log(f"✔️  成功: {result['success']}", "success")
            
            if result['healed'] > 0:
                self.master.add_log(f"🔧 自愈成功: {result['healed']} 次", "success")
                self.master.add_log(f"   （元素定位失败后自动修复）", "success")
            
            if result['error'] > 0:
                self.master.add_log(f"❌ 失败: {result['error']}", "error")
                self.master.add_log(f"错误详情（前5条）:", "warning")
                for error in result['errors'][:5]:
                    self.master.add_log(f"  - {error}", "warning")
            
            self.master.add_log(f"{'='*50}\n", "success")
            
        except Exception as e:
            self.master.add_log(f"❌ 填表出错: {e}", "error")
            import traceback
            traceback.print_exc()
        finally:
            self.start_btn.configure(state="normal", text="🚀 启动智能填表")
            self.refresh_btn.configure(state="normal")
            self.clear_mapping_btn.configure(state="normal")

    def on_closing(self):
        self.stop_event.set()
        self.destroy()
