"""
元素指纹模块

提供 ElementFingerprint 类，用于多维度标识和定位网页元素。
支持自愈选择器和表格行模式分析。

核心功能:
- 多重选择器（ID, XPath, CSS, ARIA）
- 语义锚点（Label, Placeholder, aria-label）
- 表格位置信息
- 稳定性评分
- Iframe 上下文
"""

from typing import Dict, Any, Optional, List, Union


class ElementFingerprint:
    """
    元素多维指纹
    
    存储网页元素的多维度标识信息，支持选择器自愈和表格模式分析。
    
    Attributes:
        selectors: 多重选择器字典 (id, xpath, css, aria, text)
        anchors: 语义锚点字典 (label, placeholder, aria_label 等)
        features: 元素特征字典 (tag, type, name, class, position)
        table_info: 表格位置信息
        rect: 元素坐标 (x, y, width, height)
        stability_score: 稳定性评分 (0-100)
        frame_info: Iframe 上下文信息
    """
    
    def __init__(self, element_data: Dict[str, Any]) -> None:
        """
        初始化元素指纹
        
        Args:
            element_data: 从 JS 扫描返回的原始数据字典
        """
        self.raw_data: Dict[str, Any] = element_data
        
        # 1. 多重选择器路径
        self.selectors: Dict[str, Optional[str]] = {
            'id': element_data.get('id_selector'),
            'xpath': element_data.get('xpath'),
            'css': element_data.get('css_selector'),
            'aria': element_data.get('aria_selector'),
            'text': element_data.get('text_selector')
        }
        
        # 2. 语义锚点
        self.anchors: Dict[str, str] = {
            'label': element_data.get('label_text', ''),
            'placeholder': element_data.get('placeholder', ''),
            'nearby_text': element_data.get('nearby_text', ''),
            'parent_title': element_data.get('parent_title', ''),
            'visual_label': element_data.get('visual_label', ''),
            'aria_label': element_data.get('aria_label', ''),
            'el_form_label': element_data.get('el_form_label', ''),
            'dialog_context': element_data.get('dialog_context', ''),
        }
        
        # 3. 元素特征
        self.features: Dict[str, Any] = {
            'tag': element_data.get('tagName', ''),
            'type': element_data.get('type', ''),
            'name': element_data.get('name', ''),
            'class': element_data.get('className', ''),
            'position': element_data.get('rect', {})
        }
        
        # 4. 表格位置信息
        self.table_info: Dict[str, Any] = {
            'row_index': element_data.get('row_index'),
            'col_index': element_data.get('col_index'),
            'table_id': element_data.get('table_id'),
            'is_table_cell': element_data.get('is_table_cell', False),
            'table_header': element_data.get('table_header', '')
        }
        
        # 5. 坐标信息
        self.rect: Dict[str, int] = element_data.get('rect', {
            'x': 0, 'y': 0, 'width': 0, 'height': 0
        })
        
        # 6. 稳定性评分
        self.stability_score: int = self._calculate_stability()
        
        # 7. 行模式分析
        self.row_pattern: Dict[str, Any] = element_data.get('row_pattern', {})
        
        # 8. Iframe 上下文
        self.frame_info: Dict[str, Any] = {
            'frame_path': element_data.get('frame_path', ''),
            'frame_src': element_data.get('frame_src', ''),
            'in_iframe': element_data.get('in_iframe', False),
            'frame_depth': element_data.get('frame_depth', 0)
        }
    
    def _calculate_stability(self) -> int:
        """
        计算选择器稳定性评分（100分制）
        
        评分规则:
        - ID选择器: +40分
        - aria-label: +35分
        - Element UI 标签: +25分
        - Name属性: +20分
        - ARIA/Label: +15分
        - CSS类名: +10分
        
        Returns:
            稳定性评分 (0-100)
        """
        score = 0
        
        if self.selectors.get('id'):
            score += 40
        if self.anchors.get('aria_label'):
            score += 35
        if self.anchors.get('el_form_label'):
            score += 25
        if self.features.get('name'):
            score += 20
        if self.anchors.get('label'):
            score += 15
        if self.features.get('class'):
            score += 10
        
        return min(score, 100)
    
    def get_display_name(self) -> str:
        """
        生成人类可读的元素名称
        
        优先级: aria_label > el_form_label > label > placeholder > name > id > [tag]
        
        Returns:
            元素的显示名称
        """
        if self.anchors.get('aria_label'):
            return self.anchors['aria_label']
        if self.anchors.get('el_form_label'):
            return self.anchors['el_form_label']
        if self.anchors.get('label'):
            return self.anchors['label']
        if self.anchors.get('placeholder'):
            return self.anchors['placeholder']
        if self.features.get('name'):
            return self.features['name']
        if self.selectors.get('id'):
            return self.selectors['id'].replace('#', '')
        return f"[{self.features.get('tag', 'unknown')}]"
    
    def get_best_selector(self) -> Optional[str]:
        """
        获取最稳定的选择器
        
        优先级: id > xpath > css > aria > text
        
        Returns:
            最佳选择器字符串，如果都不可用则返回 None
        """
        for key in ['id', 'xpath', 'css', 'aria', 'text']:
            if self.selectors.get(key):
                return self.selectors[key]
        return None
    
    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典格式
        
        Returns:
            包含所有指纹信息的字典
        """
        return {
            'selectors': self.selectors,
            'anchors': self.anchors,
            'features': self.features,
            'table_info': self.table_info,
            'rect': self.rect,
            'stability_score': self.stability_score,
            'frame_info': self.frame_info,
            'display_name': self.get_display_name()
        }
    
    def __repr__(self) -> str:
        return f"<ElementFingerprint: {self.get_display_name()} (score={self.stability_score})>"
