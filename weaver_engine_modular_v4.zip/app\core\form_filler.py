"""
自动填表执行器
负责遍历Excel数据并填充到网页表单
"""
import time

class FormFiller:
    """表单填充器"""
    
    @staticmethod
    def fill_form(tab, excel_data, field_mapping, after_row_action='wait', 
                  submit_button_selector=None, progress_callback=None):
        """
        自动填写表单 - 逐行填写模式
        
        Args:
            tab: DrissionPage 的 tab 对象
            excel_data: pandas DataFrame，Excel数据
            field_mapping: dict，映射关系 {excel_col: field_info}
            after_row_action: 每行填完后的操作
                - 'wait': 等待用户手动操作（默认）
                - 'submit': 自动点击提交按钮
                - 'refresh': 刷新页面
            submit_button_selector: 提交按钮的选择器（当action='submit'时使用）
            progress_callback: 进度回调函数 callback(current, total, message, status)
        
        Returns:
            dict: 填写结果统计
        """
        total_rows = len(excel_data)
        success_count = 0
        error_count = 0
        errors = []
        
        print(f"\n=== 开始自动填表（逐行模式） ===")
        print(f"总行数: {total_rows}")
        print(f"映射字段数: {len(field_mapping)}")
        print(f"每行完成后操作: {after_row_action}")
        
        # 遍历每一行数据
        for row_idx, row_data in excel_data.iterrows():
            row_num = row_idx + 1  # Excel行号（从1开始，跳过表头）
            
            try:
                if progress_callback:
                    progress_callback(row_num, total_rows, 
                                    f"📝 正在填写第 {row_num}/{total_rows} 行", "info")
                
                print(f"\n--- 填写第 {row_num} 行 ---")
                
                # 填充该行的所有映射字段
                filled_fields = 0
                for excel_col, field_info in field_mapping.items():
                    try:
                        # 获取Excel单元格的值
                        cell_value = row_data[excel_col]
                        
                        # 转换为字符串
                        if cell_value is None or (isinstance(cell_value, float) and str(cell_value) == 'nan'):
                            cell_value = ""
                        else:
                            cell_value = str(cell_value).strip()
                        
                        # 跳过空值
                        if cell_value == "":
                            continue
                        
                        # 获取网页输入元素
                        element = field_info['element']
                        field_type = field_info['type']
                        field_name = field_info.get('display_name', excel_col)
                        
                        # 根据元素类型填充
                        if field_type == 'select':
                            FormFiller._fill_select(element, cell_value)
                        elif field_type == 'textarea':
                            FormFiller._fill_textarea(element, cell_value)
                        else:
                            FormFiller._fill_input(element, cell_value, field_type)
                        
                        print(f"  ✓ [{excel_col}] = {cell_value}")
                        filled_fields += 1
                        
                        # 字段间短暂延迟
                        time.sleep(0.1)
                        
                    except Exception as e:
                        error_msg = f"第{row_num}行，字段[{excel_col}]填写失败: {e}"
                        print(f"  ✗ {error_msg}")
                        errors.append(error_msg)
                
                if filled_fields == 0:
                    print(f"  ⚠️ 第{row_num}行所有字段都为空，跳过")
                    continue
                
                print(f"  ✅ 第{row_num}行填写完成，填充了 {filled_fields} 个字段")
                
                # 执行每行完成后的操作
                if row_num < total_rows:  # 最后一行不执行after_row_action
                    if after_row_action == 'submit' and submit_button_selector:
                        try:
                            print(f"  🔘 点击提交按钮...")
                            submit_btn = tab.ele(submit_button_selector, timeout=2)
                            if submit_btn:
                                submit_btn.click()
                                time.sleep(1)  # 等待提交完成
                                print(f"  ✓ 已提交")
                        except Exception as e:
                            print(f"  ✗ 提交失败: {e}")
                    
                    elif after_row_action == 'refresh':
                        print(f"  🔄 刷新页面...")
                        tab.refresh()
                        time.sleep(2)  # 等待页面加载
                        print(f"  ✓ 页面已刷新")
                    
                    elif after_row_action == 'wait':
                        # 等待用户确认继续
                        if progress_callback:
                            progress_callback(row_num, total_rows, 
                                            f"⏸️ 第{row_num}行完成，请检查后在日志中确认继续...", "info")
                        wait_time = 3  # 给用户3秒检查
                        print(f"  ⏸️ 等待 {wait_time} 秒后继续...")
                        time.sleep(wait_time)
                
                success_count += 1
                
                if progress_callback:
                    progress_callback(row_num, total_rows, 
                                    f"✅ 第 {row_num}/{total_rows} 行完成", "success")
                
            except Exception as e:
                error_count += 1
                error_msg = f"第{row_num}行填写失败: {e}"
                print(f"❌ {error_msg}")
                errors.append(error_msg)
                
                if progress_callback:
                    progress_callback(row_num, total_rows, 
                                    f"❌ 第 {row_num} 行失败: {e}", "error")
        
        # 返回统计结果
        result = {
            'total': total_rows,
            'success': success_count,
            'error': error_count,
            'errors': errors
        }
        
        print(f"\n=== 填表完成 ===")
        print(f"成功: {success_count}/{total_rows}")
        print(f"失败: {error_count}/{total_rows}")
        
        return result
    
    @staticmethod
    def _fill_input(element, value, input_type):
        """填充input元素"""
        try:
            # 清空现有内容
            element.clear()
            time.sleep(0.05)
            
            # 输入新内容
            if input_type in ['checkbox', 'radio']:
                # 复选框/单选框：点击选中
                if str(value).lower() in ['true', '1', 'yes', '是', 'checked']:
                    element.click()
            else:
                # 文本输入：直接输入
                element.input(value)
        except Exception as e:
            # 备用方法：使用JS
            try:
                element.run_js(f"this.value = '{value}';")
            except:
                raise e
    
    @staticmethod
    def _fill_textarea(element, value):
        """填充textarea元素"""
        try:
            element.clear()
            time.sleep(0.05)
            element.input(value)
        except:
            # 备用方法
            try:
                element.run_js(f"this.value = `{value}`;")
            except:
                pass
    
    @staticmethod
    def _fill_select(element, value):
        """填充select下拉框"""
        try:
            # 方法1: 直接选择
            element.select(value)
        except:
            try:
                # 方法2: 使用JS
                element.run_js(f"this.value = '{value}';")
            except:
                # 方法3: 尝试按文本选择
                options = element.eles('tag:option')
                for option in options:
                    if option.text == value or option.attr('value') == value:
                        option.click()
                        break
