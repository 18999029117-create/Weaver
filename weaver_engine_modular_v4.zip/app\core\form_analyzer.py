"""
网页表单分析器
自动扫描和提取网页上的所有可输入元素
"""

class FormAnalyzer:
    """分析网页表单，提取所有可输入元素"""
    
    @staticmethod
    def scan_page(tab):
        """
        扫描网页上的所有输入元素
        
        Args:
            tab: DrissionPage 的 tab 对象
            
        Returns:
            list: 输入元素信息列表，每个元素包含：
                {
                    'type': 'input/textarea/select',
                    'tag': 原始标签名,
                    'name': name属性,
                    'id': id属性,
                    'placeholder': 占位符,
                    'label': 关联的label文本,
                    'element': DrissionPage元素对象
                }
        """
        print("\n=== 开始扫描网页表单 ===")
        fields = []
        
        try:
            # 1. 扫描所有 input 元素
            inputs = tab.eles('tag:input')
            print(f"找到 {len(inputs)} 个 input 元素")
            
            for idx, inp in enumerate(inputs):
                try:
                    attrs = inp.attrs or {}
                    input_type = attrs.get('type', 'text').lower()
                    
                    # 跳过按钮类型
                    if input_type in ['button', 'submit', 'reset', 'image', 'hidden']:
                        continue
                    
                    # 提取标识信息
                    name = attrs.get('name', '')
                    elem_id = attrs.get('id', '')
                    placeholder = attrs.get('placeholder', '')
                    
                    # 尝试找到关联的label
                    label_text = ''
                    if elem_id:
                        try:
                            label = tab.ele(f'css:label[for="{elem_id}"]', timeout=0.1)
                            if label:
                                label_text = label.text[:50]  # 限制长度
                        except:
                            pass
                    
                    # 生成显示名称
                    display_name = FormAnalyzer._generate_display_name(
                        name, elem_id, placeholder, label_text, input_type, f'input{idx}'
                    )
                    
                    fields.append({
                        'type': input_type,
                        'tag': 'input',
                        'name': name,
                        'id': elem_id,
                        'placeholder': placeholder,
                        'label': label_text,
                        'display_name': display_name,
                        'element': inp
                    })
                except Exception as e:
                    print(f"处理input元素失败: {e}")
                    continue
            
            # 2. 扫描所有 textarea 元素
            textareas = tab.eles('tag:textarea')
            print(f"找到 {len(textareas)} 个 textarea 元素")
            
            for idx, ta in enumerate(textareas):
                try:
                    attrs = ta.attrs or {}
                    name = attrs.get('name', '')
                    elem_id = attrs.get('id', '')
                    placeholder = attrs.get('placeholder', '')
                    
                    label_text = ''
                    if elem_id:
                        try:
                            label = tab.ele(f'css:label[for="{elem_id}"]', timeout=0.1)
                            if label:
                                label_text = label.text[:50]
                        except:
                            pass
                    
                    display_name = FormAnalyzer._generate_display_name(
                        name, elem_id, placeholder, label_text, 'textarea', f'textarea{idx}'
                    )
                    
                    fields.append({
                        'type': 'textarea',
                        'tag': 'textarea',
                        'name': name,
                        'id': elem_id,
                        'placeholder': placeholder,
                        'label': label_text,
                        'display_name': display_name,
                        'element': ta
                    })
                except:
                    continue
            
            # 3. 扫描所有 select 元素
            selects = tab.eles('tag:select')
            print(f"找到 {len(selects)} 个 select 元素")
            
            for idx, sel in enumerate(selects):
                try:
                    attrs = sel.attrs or {}
                    name = attrs.get('name', '')
                    elem_id = attrs.get('id', '')
                    
                    label_text = ''
                    if elem_id:
                        try:
                            label = tab.ele(f'css:label[for="{elem_id}"]', timeout=0.1)
                            if label:
                                label_text = label.text[:50]
                        except:
                            pass
                    
                    display_name = FormAnalyzer._generate_display_name(
                        name, elem_id, '', label_text, 'select', f'select{idx}'
                    )
                    
                    fields.append({
                        'type': 'select',
                        'tag': 'select',
                        'name': name,
                        'id': elem_id,
                        'placeholder': '',
                        'label': label_text,
                        'display_name': display_name,
                        'element': sel
                    })
                except:
                    continue
            
            print(f"✅ 扫描完成，共找到 {len(fields)} 个可用输入字段")
            return fields
            
        except Exception as e:
            print(f"❌ 扫描失败: {e}")
            import traceback
            traceback.print_exc()
            return []
    
    @staticmethod
    def _generate_display_name(name, elem_id, placeholder, label, field_type, fallback):
        """生成字段的显示名称"""
        # 优先级: label > name > id > placeholder > 默认名
        if label:
            return f"[{field_type}] {label}"
        elif name:
            return f"[{field_type}] {name}"
        elif elem_id:
            return f"[{field_type}] #{elem_id}"
        elif placeholder:
            return f"[{field_type}] {placeholder[:30]}"
        else:
            return f"[{field_type}] {fallback}"
