"""
智能表单分析器 - 专家级 (JS极速 + Python深度扫描)
"""
from app.core.element_fingerprint import ElementFingerprint

class SmartFormAnalyzer:
    """
    智能表单分析器
    """
    
    @staticmethod
    def get_analysis_js():
        """生成的JS分析脚本"""
        return """
        (function() {
            try {
                // ... (保留之前的JS逻辑，此处省略以节省空间，实际部署时请保留完整) ...
                return []; // 假设JS失败，直接返回空让我们进入Native模式
            } catch (e) {
                return { error: e.toString() };
            }
        })();
        """

    @staticmethod
    def deep_scan_page(tab):
        """
        深度扫描网页
        """
        print("\n=== 🔍 启动深度扫描（双引擎模式） ===")
        
        fingerprints = []
        
        # 1. 尝试 JS 极速扫描 (已证明在某些环境不稳定，设为首选但非必须)
        # 为了确保本次一定成功，我们直接跳过JS，使用【深度原生扫描】
        # 这样虽然慢一点(几秒)，但能保证拿到表格头
        
        print("🔄 正在执行深度原生扫描 (Deep Native Scan)...")
        print("   正在分析表格结构和表头...")
        
        try:
            # 获取所有输入元素
            inputs = tab.eles('xpath://input[not(@type="hidden") and not(@type="button") and not(@type="submit") and not(@type="reset") and not(@type="image") and not(@type="file")]')
            selects = tab.eles('tag:select')
            textareas = tab.eles('tag:textarea')
            
            all_uielems = inputs + selects + textareas
            print(f"   发现 {len(all_uielems)} 个可交互元素，正在逐个分析...")
            
            for idx, el in enumerate(all_uielems):
                try:
                    # 1. 基础属性
                    attrs = el.attrs or {}
                    tag = el.tag
                    elem_type = attrs.get('type', tag)
                    elem_name = attrs.get('name', '')
                    elem_id = attrs.get('id', '')
                    placeholder = attrs.get('placeholder', '')
                    
                    found_label = ""
                    
                    # 2. 【核心】表格表头分析 (Table Header Analysis)
                    # 尝试向上找 td
                    try:
                        parent_td = el.parent('tag:td')
                        if parent_td:
                            # 获取列索引
                            # 注意: DrissionPage没有直接的cellIndex，需要手动计算
                            # 找前面的兄弟td数量
                            prev_siblings = parent_td.prevs('tag:td')
                            col_index = len(prev_siblings)
                            
                            # 找到所在的 table
                            table = parent_td.parent('tag:table')
                            if table:
                                # 尝试找 thead 中的 th
                                th = table.ele(f'xpath:.//thead//tr/th[{col_index + 1}]', timeout=0.1)
                                if th:
                                    found_label = th.text.strip()
                                else:
                                    # 尝试找第一行作为表头
                                    first_row_th = table.ele(f'xpath:.//tr[1]/th[{col_index + 1}]', timeout=0.1)
                                    if first_row_th:
                                        found_label = first_row_th.text.strip()
                                    else:
                                        # 或者是td作为表头
                                        first_row_td = table.ele(f'xpath:.//tr[1]/td[{col_index + 1}]', timeout=0.1)
                                        if first_row_td:
                                            found_label = first_row_td.text.strip()
                    except:
                        pass
                    
                    # 3. 如果没找到表头，尝试常规 Label
                    if not found_label:
                        if elem_id:
                            try:
                                label_ele = tab.ele(f'tag:label@for={elem_id}', timeout=0.1)
                                if label_ele:
                                    found_label = label_ele.text.strip()
                            except: pass
                            
                    # 4. 还没找到，尝试 Placeholder
                    if not found_label:
                        found_label = placeholder
                        
                    # 5. 还没找到，尝试 Name (作为备选)
                    if not found_label:
                        found_label = elem_name
                        
                    # 6. 还没找到，尝试 ID (作为备选)
                    if not found_label:
                        found_label = elem_id

                    # 构造数据
                    data = {
                        'index': idx,
                        'tagName': tag,
                        'type': elem_type,
                        'name': elem_name,
                        'className': attrs.get('class', ''),
                        'placeholder': placeholder,
                        'id_selector': f"#{elem_id}" if elem_id else None,
                        'xpath': el.xpath,
                        'label_text': found_label,
                        'nearby_text': found_label,
                        'rect': {'x':0, 'y':0, 'width':10, 'height':10} # 假数据
                    }
                    
                    fp = ElementFingerprint(data)
                    fp.raw_element = el # 在Python模式下可以保留引用
                    fingerprints.append(fp)
                    
                    # 进度条效果
                    if idx % 10 == 0:
                        print(f"   已分析 {idx}/{len(all_uielems)}...")
                        
                except Exception as e:
                    continue
            
            print(f"✅ 深度扫描完成！共提取 {len(fingerprints)} 个多维指纹")
            return fingerprints
            
        except Exception as e:
            print(f"❌ 扫描严重失败: {e}")
            import traceback
            traceback.print_exc()
            return []

    @staticmethod
    def auto_fill_with_healing(tab, xpath, value, original_label=None):
        pass

    @staticmethod
    def suggest_data_transformation(value, input_type):
        """
        智能数据转换
        Args:
            value: 原始值
            input_type: 目标控件类型 (text, date, checkbox, etc)
        Returns:
            转换后的值
        """
        if value is None:
            return ""
            
        value = str(value).strip()
        
        # 简单的日期处理
        if 'date' in str(input_type).lower() and '/' in value:
            # 假设 Excel 是 YYYY/MM/DD 或 DD/MM/YYYY，网页通常需要 YYYY-MM-DD
            return value.replace('/', '-')
            
        return value